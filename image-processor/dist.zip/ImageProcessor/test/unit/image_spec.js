/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
var DiContainer = require('../../models/di_container'),
    Image = require('../../models/image'),
    ImageSpec = require('../../models/image_spec'),
    ImageProcessor = require('../../models/image_processor'),
    crypto = require('crypto'),
    Q = require('q');

describe('Image', function() {
    var meta_data_source,
        binary_data_storage,
        test_group = 'Test',
        image,
        new_meta_data_record_id = 1,
        new_binary_data_key = '/test/images/1/1',
        MimeDetector = require('../../lib/mime_detector');

    beforeEach(function() {
        image = new Image({
            _id: 1,
            binary_data: {
                key: 'test'
            }
        });
        meta_data_source = {
            insert: sinon.spy(function() {return Q(function() {return new_meta_data_record_id}).call()}),
            update: sinon.spy(function() {return Q(function() {return 1}).call()}),
            find: sinon.spy(function() {return Q(function() {return [{}]}).call()}),
            findOne: sinon.spy(function() {return Q(function() {return null}).call()}),
            remove: sinon.spy(function() {return Q(function() {return 1}).call()})
        };
        DiContainer.setComponent('image_meta_data_source', meta_data_source);

        binary_data_storage = {
            get: sinon.spy(function() {return Q(function() {return;}).call()}),
            save: sinon.spy(function() {return Q(function() {return new_binary_data_key}).call()}),
            'delete': sinon.spy(function() {return Q(function() {return true}).call()})
        };
        DiContainer.setComponent('image_binary_data_source', binary_data_storage);

        MimeDetector.detect = sinon.spy(function() {return Q(function() {return 'image/png'}).call()});
    });

    describe('Get meta data', function() {
        _it("returns copy of object's meta data", function() {
            var image = new Image({a: 1, b: 2}),
                meta_data = image.getMetaData();

            meta_data.a = 2;

            expect(image.getMetaData().a).to.have.been.equal(1);
        });
    });

    describe('Get id', function() {
        _it("returns image key", function() {
            var key = 'image_test_key',
                image = new Image({_id: key});

            expect(image.getId()).to.have.been.equal(key);
        });
    });

    describe('getBinaryData', function() {
        var http = require('http');
        var _oldRequest = http.request;
        var _oldSetBinaryData = Image.prototype.setBinaryData;
        var data = 'binary_data';
        var res, request, client
        beforeEach(function() {
            //res stub
            res = {
                setEncoding: sinon.spy(),
                on: sinon.spy(function(event, callback) {
                    if(event == 'data')
                        Q(function() {callback(data)}).call();
                    else if(event == 'end')
                        Q(function() {callback()}).call();
                })
            }
            //request stub
            request = {
                on: sinon.spy(function(event, callback) {
                    if(event == 'response')
                        Q(function() {callback(res)}).call();
                }),
                end: sinon.spy()
            }
            http.request = sinon.spy(function() {return request});

            Image.prototype.setBinaryData = sinon.spy(function() {return Q(function() {}).call()});
        });
        afterEach(function() {
            http.request = _oldRequest;
            Image.prototype.setBinaryData = _oldSetBinaryData;
        });
        _it("returns null if image does not have neither  binary data nor link to the image", function(done) {
            new Image().getBinaryData().then(function(data) {
                expect(data).to.have.been.equal(null);
                done();
            });
        });

        _it("calls binary data storage for binary data if data exists", function(done) {
            new Image({binary_data: {key: 'test'}}).getBinaryData().then(function() {
                expect(binary_data_storage.get).to.have.been.calledOnce.and.calledWith('test');
                done();
            });
        });

        _it("fetches binary image data from the external url if there is no binary data and image has link to the external source", function(done) {
            res.statusCode = 200;
            new Image({characteristics: {url: 'http://image.com/path/to/image'}}).getBinaryData().then(function(bin_data) {
                expect(http.request).to.have.been.calledOnce.and.calledWith({
                    port: 80,
                    host: 'image.com',
                    path: '/path/to/image'
                });
                expect(request.on).to.have.been.called.and.calledWith('response');
                expect(res.on).to.have.been.called.and.calledWith('data');
                expect(res.on).to.have.been.called.and.calledWith('end');
                expect(res.setEncoding).to.have.been.called.and.calledWith('binary');
                expect(request.end).to.have.been.called;
                expect(bin_data.toString()).to.have.been.equal(data);
                done();
            });
        });

        _it("saves binary image data fetched from the external url if there is no binary data and image has link to the external source", function(done) {
            res.statusCode = 200;
            new Image({characteristics: {url: 'http://image'}}).getBinaryData().then(function() {
                expect(Image.prototype.setBinaryData).to.have.been.calledOnce;
                expect(Image.prototype.setBinaryData.getCall(0).args[0].toString()).to.have.been.equal(data);
                done();
            });
        });

        _it("returns null if can not create request", function(done) {
            request.on = function(event, callback) {
                if(event == 'error')
                    callback();
            };
            new Image({characteristics: {url: 'http://image'}}).getBinaryData().then(function(bin_data) {
                expect(Image.prototype.setBinaryData).to.have.been.not.called;
                expect(bin_data).to.have.been.null;
                done();
            });
        });

        _it("returns null if fetcher returns not 200 status", function(done) {
            res.statusCode = 404;
            new Image({characteristics: {url: 'http://image'}}).getBinaryData().then(function(bin_data) {
                expect(Image.prototype.setBinaryData).to.have.been.not.called;
                expect(bin_data).to.have.been.null;
                done();
            });
        });
    });

    describe('getImageDataProcessedToSpec', function() {
        var image, spec;
        var mime_type = 'image/jpg',
            old_processToSpec_method = ImageProcessor.prototype.processToSpec,
            processed_data = 'test';

        beforeEach(function() {
            image = new Image({_id: 'test', characteristics: {type: mime_type}});
            image.getBinaryData = sinon.spy(function() {return Q(function() {return 'data'}).call()});
            spec = new ImageSpec('w100');

            ImageProcessor.prototype.processToSpec = sinon.spy(function() {return Q(function() {return processed_data;}).call()});
        });

        afterEach(function() {
            ImageProcessor.prototype.processToSpec = old_processToSpec_method;
        });

        _it('calls getBinaryData method', function(done) {
            image.getImageDataProcessedToSpec(spec).then(function() {
                expect(image.getBinaryData).to.have.been.calledOnce;
                done();
            });
        });
        _it('throws error if image does not have binary data', function(done) {
            image.getBinaryData = sinon.spy(function() {return Q(function() {return;}).call()});
            image.getImageDataProcessedToSpec(spec).catch(function(err) {
                expect(err).to.have.not.been.null;
                done();
            });
        });
        _it('calls image processor to process binary data into spec if there is no cached version', function(done) {
            image.getImageDataProcessedToSpec(spec).then(function() {
                expect(ImageProcessor.prototype.processToSpec).to.have.been.calledOnce.and.calledWith('data', spec, mime_type);
                done();
            });
        });

        describe('if cache component configured', function() {
            var key = 'new_cache_key',
                component;

            beforeEach(function() {
                component = {
                    save: sinon.spy(function() {return Q(function() {return}).call()})
                };
                DiContainer.setComponent('cache', component);
            });

            _it('saves generated data to cache', function(done) {
                var meta_data = {
                    _id: 1,
                    binary_data: {
                        key: 'test'
                    },
                    characteristics: { type: 'image/jpg' }
                };
                image.getMetaData = function() {return meta_data};

                image.getImageDataProcessedToSpec(spec).then(function() {
                    expect(component.save).to.have.been.called.and.calledWith(processed_data, 'test', spec.getKey());
                    done();
                });
            });
        });
    });

    describe('setSourceUrl', function() {
        _it('updates "characteristics"', function(done) {
            image = new Image({_id: 'test', characteristics: {type: 'image/jpg'}});
            image.setSourceUrl('test').then(function() {
                expect(meta_data_source.update).to.have.been.called.and.calledWith('test', {_id: 'test', characteristics: {type: 'image/jpg', url: 'test'}});
                done();
            });
        });
        _it('updates "characteristics"', function(done) {
            image = new Image({_id: 'test', characteristics: {type: 'image/jpg'}});
            image.setSourceUrl('test').then(function() {
                var characteristics = image.getMetaData().characteristics;
                expect(characteristics.type).to.have.been.equal('image/jpg');
                expect(characteristics.url).to.have.been.equal('test');
                done();
            });
        });
    });

    describe('setAdditionalData', function() {
        _it('sets additional data for image', function(done) {
            image = new Image({_id: 'test', characteristics: {type: 'image/jpg'}});
            image.setAdditionalData({name: 'test'}).then(function() {
                expect(meta_data_source.update).to.have.been.called.and.calledWith('test', {_id: 'test', characteristics: {type: 'image/jpg'}, additional: {name: 'test'}});
                done();
            });
        });
        _it('sets additional data for image', function(done) {
            image = new Image({_id: 'test', characteristics: {type: 'image/jpg'}});
            image.setAdditionalData({name: 'test'}).then(function() {
                expect(image.getMetaData().additional.name).to.have.been.equal('test');
                done();
            });
        });
    });

    describe('crop', function() {
        var image,
            width =100,
            height =200,
            x =50,
            y = 60;
        var mime_type = 'image/jpg',
            old_crop_method = ImageProcessor.prototype.crop,
            cropped_data = 'test';

        beforeEach(function() {
            image = new Image({_id: 'test', characteristics: {type: mime_type}});
            image.getBinaryData = sinon.spy(function() {return Q(function() {return 'data'}).call()});
            image.setBinaryData = sinon.spy(function() {return Q(function() {return}).call()});

            ImageProcessor.prototype.crop = sinon.spy(function() {return Q(function() {return cropped_data;}).call()});
        });

        afterEach(function() {
            ImageProcessor.prototype.crop = old_crop_method;
        });

        _it('extracts binary image data from the storage', function(done) {
            image.crop(width, height, x, y).then(function() {
                expect(image.getBinaryData).to.have.been.calledOnce;
                done();
            });
        });

        _it('calls image processor to crop binary data', function(done) {
            image.crop(width, height, x, y).then(function() {
                expect(ImageProcessor.prototype.crop).to.have.been.calledOnce.and.calledWith('data', width, height, x, y);
                done();
            });
        });

        _it('sets cropped image as new binary data', function(done) {
            image.crop(width, height, x, y).then(function() {
                expect(image.setBinaryData).to.have.been.calledOnce.and.calledWith(cropped_data);
                done();
            });
        });
    });

    describe('Create static method', function() {

        var old_setBinaryData = Image.prototype.setBinaryData;

        beforeEach(function() {
            Image.prototype.setBinaryData = sinon.spy(function() {return Q(function() {return}).call()});
        });

        afterEach(function() {
            Image.prototype.setBinaryData = old_setBinaryData;
        });

        _it('creates a new record in meta data storage for each image', function(done) {
            Image.create(test_group).then(function() {
                expect(meta_data_source.insert).to.have.been.called;
                done();
            });
        });

        _it('saves group name into special sub document "characteristics"', function(done) {
            Image.create(test_group).then(function() {
                expect(meta_data_source.insert.getCall(0).args[0].characteristics.group).to.have.been.equal(test_group);
                done();
            });
        });

        _it('sets binary data for created image if data has been passed in arguments', function(done) {
            Image.create(test_group, '123456').then(function() {
                expect(Image.prototype.setBinaryData).to.have.been.calledWith('123456');
                done();
            });
        });

        _it('returns the instance of for new created image', function(done) {
            Image.create(test_group, '12345').then(function(image) {
                expect(image).to.have.been.instanceOf(Image);
                var meta_data = image.getMetaData();
                expect(meta_data._id).to.have.been.equal(new_meta_data_record_id);
                expect(meta_data.characteristics.group).to.have.been.equal(test_group);
                done();
            });
        });

        _it('accepts additional info for create method and saves this info into special sub document "additional"', function(done) {
            var additional_info = {
                a: 'test',
                b: [1, 2, 3]
            }
            Image.create(test_group, '123456', additional_info).then(function() {
                expect(meta_data_source.insert.getCall(0).args[0].additional).to.have.been.equal(additional_info);
                done();
            });
        });
    });

    describe('CreateFromFile static method', function() {
        _it('calls delegates to the create method', function(done) {
            sinon.spy(Image, 'create');
            var additional = {a: 1, b: [1,2]};
            Image.createFromFile('test', 'test/fixtures/domino.png', additional).then(function() {
                expect(Image.create).to.have.been.called;
                expect(Image.create.getCall(0).args[0]).to.have.been.equal('test');
                expect(Image.create.getCall(0).args[2]).to.have.been.equal(additional);
                Image.create.restore();
                done();
            });
        });
        _it('throws an error if a file link is broken', function(done) {
            Image.createFromFile(test_group, '/test_file').catch(function(err) {
                expect(err.message).to.be.equal('Wrong file path!');
                done();
            });
        });
    });

    describe('CreateFromUrl static method', function() {
        var url = 'http://path/to/image';

        _it('searches for existed image with given url source', function(done) {
            Image.createFromUrl(test_group, url).then(function() {
                expect(meta_data_source.findOne).to.have.been.calledWith({'characteristics.url': url});
                done();
            });
        });

        _it('returns found image if it does exist', function(done) {
            var image_data = {
                id: 'test',
                characteristics: {
                    url: url
                }
            };
            meta_data_source.findOne = function() {return Q(function() {return image_data}).call()};
            Image.createFromUrl(test_group, url).then(function(image) {
                expect(image.getMetaData().id).to.have.been.equal('test');
                expect(image.getMetaData().characteristics.url).to.have.been.equal(url);
                expect(meta_data_source.insert).to.have.not.been.called;
                done();
            });
        });

        describe('if image with given url does not exists', function() {
            _it('creates a new record in meta data storage for each image', function(done) {
                Image.createFromUrl(test_group, url).then(function() {
                    expect(meta_data_source.insert).to.have.been.called;
                    done();
                });
            });

            _it('saves group name into special sub document "characteristics"', function(done) {
                Image.createFromUrl(test_group, url).then(function() {
                    expect(meta_data_source.insert.getCall(0).args[0].characteristics.group).to.have.been.equal(test_group);
                    done();
                });
            });

            _it('saves url into special sub document "characteristics"', function(done) {
                Image.createFromUrl(test_group, url).then(function() {
                    expect(meta_data_source.insert.getCall(0).args[0].characteristics.url).to.have.been.equal(url);
                    done();
                });
            });

            _it('returns the instance of for new created image', function(done) {
                Image.createFromUrl(test_group, url).then(function(image) {
                    expect(image).to.have.been.instanceOf(Image);
                    var meta_data = image.getMetaData();
                    expect(meta_data._id).to.have.been.equal(new_meta_data_record_id);
                    expect(meta_data.characteristics.group).to.have.been.equal(test_group);
                    done();
                });
            });

            _it('accepts additional info for create method and saves this info into special sub document "additional"', function(done) {
                var additional_info = {
                    a: 'test',
                    b: [1, 2, 3]
                }
                Image.createFromUrl(test_group, url, additional_info).then(function() {
                    expect(meta_data_source.insert.getCall(0).args[0].additional).to.have.been.equal(additional_info);
                    done();
                });
            });
        });
    });

    describe('Static get method', function() {
        _it('accepts a query param and passes it to meta data source find method', function(done) {
            var query = {_id: 1};
            Image.get(query).then(function() {
                expect(meta_data_source.find).to.have.been.calledWith(query);
                done();
            });
        });

        _it('accepts offset and passes it to data source find method', function(done) {
            Image.get({}, 2).then(function() {
                expect(meta_data_source.find.getCall(0).args[1]).to.have.been.equal(2);
                done();
            });
        });

        _it('accepts limit and passes it to data source find method', function(done) {
            Image.get({}, 2, 3).then(function() {
                expect(meta_data_source.find.getCall(0).args[2]).to.have.been.equal(3);
                done();
            });
        });

        _it('returns Image instances', function(done) {
            meta_data_source.find = sinon.spy(function() {return Q(function() {return [{}, {}]}).call()});
            Image.get({}).then(function(images) {
                for(var i in images)
                    expect(images[i]).to.have.been.instanceOf(Image);
                done();
            });
        });
    });

    describe('Set binary data method', function() {
        var binary_data = 'aaaaaaa',
            converted_binary_data = 'converted_data',
            dimensions = {width: 400, height: 400},
            old_getImageDimensions = ImageProcessor.prototype.getImageDimensions;

        beforeEach(function() {
            sinon.spy(image, 'setBinaryData');
            ImageProcessor.prototype.getImageDimensions = sinon.spy(function() {return Q(function() {return dimensions}).call()});
        })

        afterEach(function() {
            image.setBinaryData.restore();
            ImageProcessor.prototype.getImageDimensions = old_getImageDimensions;
        });

        _it('creates new binary data entry in storage', function(done) {

            image.setBinaryData(binary_data).then(function() {
                expect(binary_data_storage.save).to.have.been.calledWith(converted_binary_data);
                done();
            });
        });

        _it('updates sub document "binary_data" for image meta data', function(done) {
            image.setBinaryData(binary_data).then(function() {
                expect(meta_data_source.update).to.have.been.called;
                expect(meta_data_source.update.getCall(0).args[0]).to.have.been.equal(image.getMetaData()._id);
                expect(meta_data_source.update.getCall(0).args[1].binary_data.key).to.have.been.equal(new_binary_data_key);
                expect(meta_data_source.update.getCall(0).args[1].binary_data.bites).to.have.been.equal(converted_binary_data.length);
                expect(meta_data_source.update.getCall(0).args[1].binary_data.digest).to.have.been.equal(crypto.createHash('md5').update(binary_data).digest('hex'));
                done();
            });
        });

        _it('do search for binary data to prevent data duplication', function(done) {
            image.setBinaryData(binary_data).then(function() {
                expect(meta_data_source.findOne).to.have.been.calledWith({
                    'binary_data.bites': converted_binary_data.length,
                    'binary_data.digest': crypto.createHash('md5').update(binary_data).digest('hex')
                });
                done();
            });
        });

        _it('should not create new data entry if existed data has been found', function(done) {
            var existed_binary_data_key = 'test';
            meta_data_source.findOne = sinon.spy(function() {return Q(function() {return {binary_data: {key: existed_binary_data_key}}}).call()});
            image.setBinaryData(binary_data).then(function() {
                expect(binary_data_storage.save.getCall(0).args[1]).to.have.been.equal(existed_binary_data_key);
                done();
            });
        });

        _it('gets image mime type from data', function(done) {
            Image.create(test_group, '123456').then(function() {
                expect(MimeDetector.detect).to.have.been.called;
                done();
            });
        });

        _it('calls ImageProcessor.getImageDimensions method', function(done) {
            image.setBinaryData(binary_data).then(function() {
                expect(ImageProcessor.prototype.getImageDimensions).to.have.been.called.and.calledWith(converted_binary_data);
                done();
            });
        });

        _it('updates the internal object state', function(done) {
            image.setBinaryData(binary_data).then(function() {
                var meta_data = image.getMetaData();
                expect(meta_data.characteristics.type).to.have.been.equal('image/png');
                expect(meta_data.characteristics.dimensions).to.have.been.equal(dimensions);
                expect(meta_data.binary_data.key).to.have.been.equal(new_binary_data_key);
                expect(meta_data.binary_data.bites).to.have.been.equal(converted_binary_data.length);
                expect(meta_data.binary_data.digest).to.have.been.equal(crypto.createHash('md5').update(binary_data).digest('hex'));
                done();
            });
        });

        _it('throws error if mime type of data is not allowed', function(done) {
            MimeDetector.detect = sinon.spy(function() {return Q(function() {return 'text/html'}).call()});
            image.setBinaryData('123456').catch(function(err) {
                expect(err.message).to.have.been.equal('Wrong data type');
                done();
            });
        });

        _it('checks if previous binary data is connected to other images before delete it', function(done) {
            var meta_data = image.getMetaData();
            meta_data_source.find = sinon.spy(function() {return Q(function() {return [{}]}).call()});
            image.setBinaryData(binary_data).then(function() {
                expect(meta_data_source.find).to.have.been.calledWith({'binary_data.key': meta_data.binary_data.key});
                expect(binary_data_storage.delete).to.not.have.been.called;
                done();
            });
        });

        _it('deletes binary data from storage', function(done) {
            DiContainer.setComponent('cache', null)
            var meta_data = image.getMetaData(),
                key = meta_data.binary_data.key;
            meta_data_source.find = sinon.spy(function() {return Q(function() {return []}).call()});
            image.setBinaryData(binary_data).then(function() {
                expect(binary_data_storage.delete).to.have.been.calledWith(key);
                done();
            });
        });

        _it('deletes all cached versions from cache if it is configured', function(done) {
            var cache = {delete: sinon.spy()};
            DiContainer.setComponent('cache', cache)
            var meta_data = image.getMetaData(),
                key = meta_data.binary_data.key;
            meta_data_source.find = sinon.spy(function() {return Q(function() {return []}).call()});
            image.setBinaryData(binary_data).then(function() {
                expect(cache.delete).to.have.been.calledWith(key);
                done();
            });
        });
    });

    describe('Delete method', function() {
        _it('deletes meta data record from meta data source', function(done) {
            var meta_data = image.getMetaData();
            image.delete().then(function() {
                expect(meta_data_source.remove).to.have.been.calledWith(meta_data._id);
                done();
            });
        });

        _it('checks if binary data is connected to other images before delete it', function(done) {
            var meta_data = image.getMetaData();
            meta_data_source.find = sinon.spy(function() {return Q(function() {return [{}]}).call()});
            image.delete().then(function() {
                expect(meta_data_source.find).to.have.been.calledWith({'binary_data.key': meta_data.binary_data.key});
                expect(binary_data_storage.delete).to.not.have.been.called;
                done();
            });
        });

        _it('deletes binary data from storage', function(done) {
            DiContainer.setComponent('cache', null)
            var meta_data = image.getMetaData();
            meta_data_source.find = sinon.spy(function() {return Q(function() {return []}).call()});
            image.delete().then(function() {
                expect(binary_data_storage.delete).to.have.been.calledWith(meta_data.binary_data.key);
                done();
            });
        });

        _it('deletes all cached versions from cache if it is configured', function(done) {
            var cache = {delete: sinon.spy()};
            DiContainer.setComponent('cache', cache)
            var meta_data = image.getMetaData();
            meta_data_source.find = sinon.spy(function() {return Q(function() {return []}).call()});
            image.delete().then(function() {
                expect(cache.delete).to.have.been.calledWith(meta_data.binary_data.key);
                done();
            });
        });
    });
});