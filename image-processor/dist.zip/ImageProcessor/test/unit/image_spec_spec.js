/**
 * Created by dmytro@clevertech.biz on 23.01.14.
 */
var ImageSpec = require('../../models/image_spec');
describe('routes', function(){
    return describe('ImageSpec', function(){
        _it('can set image width from key string', function() {
            var spec = new ImageSpec('w123');
            expect(spec.getWidth()).to.have.been.equal(123);
        });

        _it('can set image height from key string', function() {
            var spec = new ImageSpec('h123');
            expect(spec.getHeight()).to.have.been.equal(123);
        });

        _it('throws error if there is no width or height param', function() {
            try {
                new ImageSpec('cw234');
                expect(false).to.have.been.equal(true);
            } catch(e) {
                expect(e.message).to.have.been.equal('Wrong spec format!');
            }
        });

        _it('can parse params from complex key', function() {
            var spec = new ImageSpec('h123_w456_ch123_cw456_cx10_cy10');
            expect(spec.getHeight()).to.have.been.equal(123);
            expect(spec.getWidth()).to.have.been.equal(456);
            expect(spec.getCropHeight()).to.have.been.equal(123);
            expect(spec.getCropWidth()).to.have.been.equal(456);
            expect(spec.getCropX()).to.have.been.equal(10);
            expect(spec.getCropY()).to.have.been.equal(10);
        });

        _it('can parse params from object', function() {
            var spec = new ImageSpec({width: 456, height: 123, crop_width: 456, crop_height: 123, crop_x: 10, crop_y: 10});
            expect(spec.getHeight()).to.have.been.equal(123);
            expect(spec.getWidth()).to.have.been.equal(456);
            expect(spec.getCropHeight()).to.have.been.equal(123);
            expect(spec.getCropWidth()).to.have.been.equal(456);
            expect(spec.getCropX()).to.have.been.equal(10);
            expect(spec.getCropY()).to.have.been.equal(10);
        });

        _it('returns 0 if some of the spec params is undefined for this param getter', function() {
            var getters = ['getHeight', 'getCropWidth', 'getCropHeight', 'getCropX', 'getCropY'],
                spec = new ImageSpec({width: 100});
            for(var i in getters)
                expect(spec[getters[i]]()).to.have.been.equal(0);

            spec = new ImageSpec({height: 100});
            expect(spec.getWidth()).to.have.been.equal(0);
        });

        _it('generates a key based on the specs', function() {
            var spec = new ImageSpec({width: 456, height: 123, crop_width: 456, crop_height: 123, crop_x: 10, crop_y: 10});
            expect(spec.getKey()).to.have.been.equal('w456_h123_cw456_ch123_cx10_cy10');
        });

        _it('detects if the spec has crop params(crop width or crop height)', function() {
            expect(new ImageSpec({width: 100}).hasCropParams()).to.have.been.false;
            expect(new ImageSpec({width: 100, crop_width: 50}).hasCropParams()).to.have.been.true;
            expect(new ImageSpec({width: 100, crop_height: 50}).hasCropParams()).to.have.been.true;
        });
    });
});