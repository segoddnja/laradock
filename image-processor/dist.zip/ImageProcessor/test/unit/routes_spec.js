/**
 * Created by dmytro@clevertech.biz on 16.12.13.
 */
require('buffer');

var routes = require('../../lib/routes'),
    Image = require('../../models/image'),
    ImageSpec = require('../../models/image_spec'),
    ImageUrlFetcher = require('../../models/image_url_fetcher'),
    DiContainer = require('../../models/di_container'),
    Q = require('q');
describe('routes', function(){
    return describe('#apply(server)', function(){
        var server, get_route_callbacks, post_route_callbacks, put_route_callbacks, delete_route_callbacks;
        beforeEach(function(){
            get_route_callbacks = {};
            post_route_callbacks = {};
            put_route_callbacks = {};
            delete_route_callbacks = [];
            server = {
                get: function(route, cb){
                    return get_route_callbacks[route] = cb;
                },
                post: function(route, cb){
                    return post_route_callbacks[route] = cb;
                },
                put: function(route, cb){
                    return put_route_callbacks[route] = cb;
                },
                del: function(route, cb) {
                    return delete_route_callbacks[route] = cb;
                }
            };
            sinon.spy(server, 'get');
            sinon.spy(server, 'post');
            sinon.spy(server, 'put');
            sinon.spy(server, 'del');
            routes.apply(server);
        });
        afterEach(function(){
            server.get.restore();
            server.post.restore();
        });

        describe('creates route: GET /images' ,function() {
            var route = '/images';
            var cb, res;
            var old_image_get = Image.get,
                query = '{"_id": "345"}';

            var stub_image_get = function(response) {
                Image.get = sinon.spy(function() {return Q(function() {return response;}).call()});
            }
            beforeEach(function() {
                stub_image_get([]);
                cb = get_route_callbacks[route];
                sinon.spy(res = {
                    send: function(){}
                }, 'send');
            });
            afterEach(function() {
                Image.get = old_image_get;
            });
            _it('', function(){
                expect(server.get).to.have.been.calledWith(route);
            });
            _it('responds with 400 if "query" param has not been passed', function(done){
                cb({}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('tries to parse JSON from query param', function(done){
                sinon.spy(JSON, 'parse');
                cb({params: {query: query}}, res).then(function() {
                    expect(JSON.parse).to.have.been.calledOnce.and.calledWith(query);
                    JSON.parse.restore();
                    done();
                });
            });
            _it('responds with 400 if query is not proper json string', function(done){
                cb({params: {query: 'wrong_json'}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('calls Image.get for images', function(done){
                cb({params: {query: query}}, res).then(function() {
                    expect(Image.get).to.have.been.calledOnce;
                    done();
                });
            });
            _it('accepts offset param and passes it to Image.get method', function(done){
                cb({params: {query: query, offset: 10}}, res).then(function() {
                    expect(Image.get.getCall(0).args[1]).to.have.been.equal(10);
                    done();
                });
            });
            _it('accepts limit param and passes it to Image.get method', function(done){
                cb({params: {query: query, limit: 20}}, res).then(function() {
                    expect(Image.get.getCall(0).args[2]).to.have.been.equal(20);
                    done();
                });
            });

            _it('creates an ImageUrlFetcher instance if request has specs passed', function(done) {
                var image1 = new Image({_id: 'key1'}),
                    image2 = new Image({_id: 'key2'});
                stub_image_get([image1, image2]);

                sinon.spy(ImageUrlFetcher.prototype, 'init');

                cb({params: {query: query, specs: ['w100']}}, res).then(function() {
                    expect(ImageUrlFetcher.prototype.init).to.have.been.called.and.calledWith([image1, image2], ['w100']);
                    ImageUrlFetcher.prototype.init.restore();
                    done();
                });
            });

            _it('calls getUrl method of ImageUrlFetcher instance for each found image and each spec', function(done) {
                var image1 = new Image({_id: 'key1', characteristics: {}}),
                    image2 = new Image({_id: 'key2', characteristics: {}});
                stub_image_get([image1, image2]);

                sinon.spy(ImageUrlFetcher.prototype, 'getUrl');

                cb({params: {query: query, specs: ['w100', 'h200']}}, res).then(function() {
                    expect(ImageUrlFetcher.prototype.getUrl.callCount).to.have.been.equal(4);
                    ImageUrlFetcher.prototype.getUrl.restore();
                    done();
                });
            });

            _it('returns each found image in response', function(done){
                var image1 = new Image({_id: 'key1', characteristics: {}}),
                    image2 = new Image({_id: 'key2', characteristics: {}});
                stub_image_get([image1, image2]);

                cb({params: {query: query, specs: ['w100']}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce;
                    var images = res.send.getCall(0).args[1];
                    expect(images['key1']).to.have.been.instanceOf(Object);
                    expect(images['key2']).to.have.been.instanceOf(Object);
                    done();
                });
            });

            _it('returns image characteristics and additional info', function(done) {
                var image1 = new Image({_id: 'key1', characteristics: {length: 123, digest: '1234324234'}, additional: {key1: 'test'}});
                stub_image_get([image1]);

                cb({params: {query: query, specs: ['w100']}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce;
                    var image = res.send.getCall(0).args[1]['key1'];
                    expect(image.characteristics).to.have.been.equal(image1.getMetaData().characteristics);
                    expect(image.additional).to.have.been.equal(image1.getMetaData().additional);
                    done();
                });
            });

        });

        describe('creates route: POST /images' ,function() {
            var route = '/images';
            var uploaded_image = {
                size: 247620,
                path: "/tmp/61a7ebd6019f2766c83c7cd6794b48fc",
                name: "12daysDomino-Mobile.jpg",
                type: "image/jpeg",
                mtime: "2014-01-22T10:07:15.967Z"
            };
            var profile = 'test';
            var _oldCreateFromFile = Image.createFromFile;
            var _oldCreate = Image.create;
            var _oldCreateFromUrl = Image.createFromUrl;
            var cb, res;
            beforeEach(function() {
                cb = post_route_callbacks[route];
                sinon.spy(res = {
                    send: function(){}
                }, 'send');
                Image.createFromFile = sinon.spy(function() {return Q(function() {return new Image({_id: 123})}).call()});
                Image.create = sinon.spy(function() {return Q(function() {return new Image({_id: 123})}).call()});
                Image.createFromUrl = sinon.spy(function() {return Q(function() {return new Image({_id: 123})}).call()});
            });
            afterEach(function() {
                Image.createFromFile = _oldCreateFromFile;
                Image.create = _oldCreate;
                Image.createFromUrl = _oldCreateFromUrl;
            });
            _it('', function(){
                expect(server.post).to.have.been.calledWith(route);
            });
            _it('responds with 400 if "profile" param has not been passed', function(done){
                cb({params: {}, files: {img: uploaded_image}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done();
                });
            });
            _it('responds with 400 if "img" file or image data or url to source image in the request body has not been passed', function(done){
                cb({params: {profile: profile}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('creates a new image using profile and image file(if it is passed)', function(done) {
                cb({params: {profile: profile}, files: {img: uploaded_image}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(200);
                    expect(Image.createFromFile).to.have.been.calledOnce.and.calledWith('test', '/tmp/61a7ebd6019f2766c83c7cd6794b48fc');
                    done();
                });
            });
            _it('creates a new image using profile and image data(if it is passed)', function(done) {
                cb({params: {profile: profile, img: 'binary_data'}}, res).then(function() {
                    var buffer = new Buffer('binary_data', 'base64'),
                        args = Image.create.getCall(0).args;

                    expect(res.send).to.have.been.calledOnce.and.calledWith(200);
                    expect(args[0]).to.have.been.equal('test');
                    expect(args[1].toString()).to.have.been.equal(buffer.toString());
                    done();
                });
            });
            _it('creates a new image using profile and image url(if it is passed)', function(done) {
                var url = "http://link/to/image";
                cb({params: {profile: profile, url: url}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(200);
                    expect(Image.createFromUrl).to.have.been.calledOnce.and.calledWith(profile, url);
                    done();
                });
            });
            _it('passes additional data from request', function(done) {
                var add_data = {'first': 1, 'second': 2};
                cb({params: {profile: profile, additional: add_data}, files: {img: uploaded_image}}, res).then(function() {
                    expect(Image.createFromFile).to.have.been.calledOnce.and.calledWith('test', '/tmp/61a7ebd6019f2766c83c7cd6794b48fc', add_data);
                    done();
                });
            });
        });

        describe('creates route: PUT /images/:id' ,function() {
            var route = '/images/:id';
            var cb, res;
            beforeEach(function() {
                cb = put_route_callbacks[route];
                sinon.spy(res = {
                    send: function(){}
                }, 'send');
            });
            _it('', function(){
                expect(server.put).to.have.been.calledWith(route);
            });
            _it('does nothing if both image data and additional info not passed', function(done) {
                sinon.stub(Image, 'get', function() {return Q(function(){return []}).call()});
                cb({params: {id: 'test'}}, res).then(function() {
                    expect(Image.get).to.have.been.not.called;
                    expect(res.send).to.have.been.called.and.calledWith(200, {key: 'test'})
                    Image.get.restore();
                    done();
                });
            });
            _it('searches for image by given id', function(done) {
                sinon.stub(Image, 'get', function() {return Q(function(){return []}).call()});
                cb({params: {id: 'test', additional: {param: 1}}}, res).then(function() {
                    expect(Image.get).to.have.been.called.and.calledWith({_id: 'test'}, 0, 1);
                    Image.get.restore();
                    done();
                });
            });
            _it('responds with 404 if image with given id does not exist', function(done) {
                sinon.stub(Image, 'get', function() {return Q(function(){return []}).call()});
                cb({params: {id: 'test', additional: {param: 1}}}, res).then(function() {
                    expect(res.send).to.have.been.called.and.calledWith(404);
                    Image.get.restore();
                    done();
                });
            });

            describe('if image exists', function() {
                var image;

                beforeEach(function() {
                    image = new Image({_id: 'test'});
                    sinon.stub(image, 'setBinaryData', function() {return Q(function(){return}).call()});
                    sinon.stub(image, 'setSourceUrl', function() {return Q(function(){return}).call()});
                    sinon.stub(image, 'setAdditionalData', function() {return Q(function(){return}).call()});

                    sinon.stub(Image, 'get', function() {return Q(function(){return [image]}).call()});
                });

                afterEach(function() {
                    Image.get.restore();
                });

                describe('if uploaded img file passed in params', function() {
                    var uploaded_image = {
                        size: 247620,
                        path: "/tmp/61a7ebd6019f2766c83c7cd6794b48fc",
                        name: "12daysDomino-Mobile.jpg",
                        type: "image/jpeg",
                        mtime: "2014-01-22T10:07:15.967Z"
                    };

                    var fs = require('fs');
                    beforeEach(function() {
                        sinon.stub(fs, 'readFile', function(path, callback) {callback(null, 'file_content')});
                    });

                    afterEach(function() {
                        fs.readFile.restore();
                    });

                    _it('reads file content', function(done) {
                        cb({params: {id: 'test', url: 'test', additional: {param: 1}}, files: {img: uploaded_image}}, res).then(function() {
                            expect(fs.readFile).to.have.been.called.and.calledWith(uploaded_image.path);
                            done();
                        });
                    });
                    _it('sets binary data for image', function(done) {
                        cb({params: {id: 'test', url: 'test', additional: {param: 1}}, files: {img: uploaded_image}}, res).then(function() {
                            expect(image.setBinaryData).to.have.been.called.and.calledWith('file_content');
                            done();
                        });
                    });
                });

                _it('sets binary data it it is passed in request body', function(done) {
                    cb({params: {id: 'test', url: 'test', img: 'binary_data', additional: {param: 1}}}, res).then(function() {
                        var args = image.setBinaryData.getCall(0).args;
                        expect(image.setBinaryData).to.have.been.called;
                        expect(args[0].toString()).to.have.been.equal(new Buffer('binary_data', 'base64').toString());
                        done();
                    });
                });

                _it('sets image source url if it is passed and no binary data and uploaded file passed', function(done) {
                    cb({params: {id: 'test', url: 'test', additional: {param: 1}}}, res).then(function() {
                        expect(image.setSourceUrl).to.have.been.called.and.calledWith('test');
                        done();
                    });
                });

                _it('sets additional params if they passed', function(done) {
                    cb({params: {id: 'test', url: 'test', additional: {param: 1}}}, res).then(function() {
                        expect(image.setAdditionalData).to.have.been.called.and.calledWith({param: 1});
                        done();
                    });
                });

                _it('sets additional params if they passed', function(done) {
                    cb({params: {id: 'test', additional: {param: 1}}}, res).then(function() {
                        expect(image.setAdditionalData).to.have.been.called.and.calledWith({param: 1});
                        done();
                    });
                });
            });
        });

        describe('creates route: DELETE /images/:id' ,function() {
            var route = '/images/:id';
            var cb, res;
            beforeEach(function() {
                cb = delete_route_callbacks[route];
                res = {
                    send: function(){},
                    end: function(){}
                }
                sinon.spy(res, 'send');
                sinon.spy(res, 'end');
            });
            _it('', function(){
                expect(server.del).to.have.been.calledWith(route);
            });
            _it('responds with 400 if id param has not been passed', function(done){
                cb({}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('searches image by id', function(done){
                var old_get = Image.get;
                Image.get = function() {return Q(function() {return [];}).call()};
                sinon.spy(Image, 'get');
                cb({params: {id: 1}}, res).then(function() {
                    expect(Image.get).to.have.been.calledOnce.and.calledWith({_id: 1}, 0, 1);
                    Image.get = old_get;
                    done()
                });
            });
            _it('responds with 404 if image with given id is not found', function(done){
                var old_get = Image.get;
                Image.get = function() {return Q(function() {return [];}).call()};
                cb({params: {id: 1}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(404);
                    Image.get = old_get;
                    done();
                });
            });
            _it('deletes image', function(done){
                var old_get = Image.get,
                    image = {'delete': sinon.spy(function() {})};
                Image.get = function() {return Q(function() {return [image];}).call()};
                cb({params: {id: 1}}, res).then(function() {
                    expect(image.delete).to.have.been.calledOnce;
                    expect(res.end).to.have.been.calledOnce;
                    Image.get = old_get;
                    done();
                });
            });
        });

        describe('creates route: POST /images/:id/crop' ,function() {
            var route = '/images/:id/crop';
            var cb, res;
            beforeEach(function() {
                cb = post_route_callbacks[route];
                res = {
                    send: function(){},
                    end: function(){}
                }
                sinon.spy(res, 'send');
                sinon.spy(res, 'end');
            });
            _it('', function(){
                expect(server.post).to.have.been.calledWith(route);
            });
            _it('responds with 400 if id param has not been passed', function(done){
                cb({params: {x: 100, y: 200, width: 500, height: 600}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('responds with 400 if x crop param has not been passed', function(done){
                cb({params: {id: 1, y: 200, width: 500, height: 600}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('responds with 400 if y crop param has not been passed', function(done){
                cb({params: {id: 1, x: 100, width: 500, height: 600}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('responds with 400 if width crop param has not been passed', function(done){
                cb({params: {id: 1, x: 100, y: 200, height: 600}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('responds with 400 if height crop param has not been passed', function(done){
                cb({params: {id: 1, x: 100, y: 200, width: 500}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('searches image by id', function(done){
                var old_get = Image.get;
                Image.get = function() {return Q(function() {return [];}).call()};
                sinon.spy(Image, 'get');
                cb({params: {id: 1, x: 100, y: 200, width: 500, height: 600}}, res).then(function() {
                    expect(Image.get).to.have.been.calledOnce.and.calledWith({_id: 1}, 0, 1);
                    Image.get = old_get;
                    done()
                });
            });
            _it('responds with 404 if image with given id is not found', function(done){
                var old_get = Image.get;
                Image.get = function() {return Q(function() {return [];}).call()};
                cb({params: {id: 1, x: 100, y: 200, width: 500, height: 600}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(404);
                    Image.get = old_get;
                    done();
                });
            });
            _it('crops image', function(done) {
                var old_get = Image.get,
                    image = {'crop': sinon.spy(function() {})};
                Image.get = function() {return Q(function() {return [image];}).call()};
                cb({params: {id: 1, x: 100, y: 200, width: 500, height: 600}}, res).then(function() {
                    expect(image.crop).to.have.been.calledOnce.and.calledWith(500, 600, 100, 200);
                    expect(res.end).to.have.been.calledOnce;
                    Image.get = old_get;
                    done();
                });
            })
        });

        describe('creates route: GET /gen' ,function() {
            var route = '/gen';
            var cb, res, next;
            var spec = 'w123';
            beforeEach(function() {
                DiContainer.setComponent('cache', null);
                cb = get_route_callbacks[route];
                res = {
                    send: function(){},
                    writeHead: function(){},
                    end: function(){}
                }
                sinon.spy(res, 'send');
                sinon.spy(res, 'writeHead');
                sinon.spy(res, 'end');
                next = sinon.spy();
            });
            _it('', function(){
                expect(server.get).to.have.been.calledWith(route);
            });
            _it('responds with 400 if image key is not specified', function(done) {
                cb({query: {'spec': spec}}, res, next).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done();
                });
            });
            _it('responds with 400 if image spec is not specified', function(done) {
                cb({query: {'key': 'test'}}, res, next).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(400);
                    done()
                });
            });
            _it('searches for the image', function(done) {
                Image.get = sinon.spy(function() {return Q(function() {return []}).call()});
                cb({query: {'key': 'test', 'spec': spec}}, res, next).then(function() {
                    expect(Image.get).to.have.been.calledOnce;
                    expect(Image.get.getCall(0).args[0]._id).to.have.been.equal('test');
                    done();
                });
            });
            describe('if cache component configured', function() {
                var urls = {},
                    cache,
                    binary_data_key = 'binary_data_key';
                beforeEach(function() {
                    Image.get = sinon.spy(function() {return Q(function() {return [
                        new Image({_id: 'test', binary_data: {key: binary_data_key}})
                    ]}).call()});
                    cache = {
                        getUrls: sinon.spy(function() {return Q(function() {return urls}).call()})
                    }
                    DiContainer.setComponent('cache', cache);
                });
                _it('calls cache component to get a cached version', function(done) {
                    cb({query: {'key': 'test', 'spec': 'w100_h200'}}, res, next).then(function() {
                        expect(cache.getUrls).to.have.been.calledOnce.and.calledWith('binary_data_key', ['w100_h200']);
                        done()
                    });
                });
                _it('does not call cache component if the special flag "nocache" passed with query params', function(done) {
                    cb({query: {'key': 'test', 'spec': 'w100_h200', 'nocache': 1}}, res, next).then(function() {
                        expect(cache.getUrls).to.have.been.not.called;
                        done()
                    });
                });
                _it('redirects to the cached version url', function(done) {
                    urls = {binary_data_key: {
                        w100_h200: 'http://cache/12345'
                    }}
                    cb({query: {'key': 'test', 'spec': 'w100_h200'}}, res, next).then(function() {
                        expect(res.writeHead).to.have.been.calledOnce.and.calledWith(301, {Location: 'http://cache/12345'});
                        done()
                    });
                });
            });
            _it('processes image data to the spec and responds with 200 status', function(done) {
                var image = {
                    getImageDataProcessedToSpec: sinon.spy(function() {return Q(function() {return 'test';}).call()}),
                    getBinaryDataKey: function() {},
                    getMetaData: function() {return {characteristics: {}}}
                }
                Image.get = sinon.spy(function() {return Q(function() {return [image]}).call()});
                cb({query: {'key': 'test', 'spec': spec}}, res, next).then(function() {
                    expect(image.getImageDataProcessedToSpec).to.have.been.calledOnce;
                    expect(image.getImageDataProcessedToSpec.getCall(0).args[0]).to.have.been.instanceOf(ImageSpec);
                    expect(res.end).to.have.been.calledOnce.and.calledWith('test');
                    done();
                });
            });
            _it('responds with 400 if getImageDataProcessedToSpec throws error', function(done) {
                var image = {
                    getImageDataProcessedToSpec: sinon.spy(function() {return Q(function() {throw new Error('test')}).call()}),
                    getBinaryDataKey: function() {}
                }
                Image.get = sinon.spy(function() {return Q(function() {return [image]}).call()});
                cb({query: {'key': 'test', 'spec': spec}}, res, next).then(function() {
                    expect(res.send.getCall(0).args[0]).to.have.been.equal(400);
                    expect(res.send.getCall(0).args[1].error).to.have.been.equal('test');
                    done();
                });
            });
        });

        describe('creates route: GET /cache/:key' ,function() {
            var route = /\/cache\/(.*)/;
            var cb, res, next;
            beforeEach(function() {
                cb = get_route_callbacks[route];
                res = {
                    send: function(){},
                    end: function(){},
                    writeHead: function(){}
                }
                sinon.spy(res, 'send');
                sinon.spy(res, 'end');
                sinon.spy(res, 'writeHead');
                next = sinon.spy();
            });
            _it('', function(){
                expect(server.get).to.have.been.calledWith(route);
            });
            _it('responds with 404 if cache component is not configured', function(done) {
                DiContainer.setComponent('cache', null);
                cb({}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(404);
                    done();
                });
            });
            _it('calls get method of cache component', function(done) {
                var component = {get: sinon.spy(function() {return Q(function() {return;}).call()})}
                DiContainer.setComponent('cache', component);
                cb({params: {0: 'key'}}, res).then(function() {
                    expect(component.get).to.have.been.calledOnce.and.calledWith('key');
                    done();
                });
            });
            _it('responds with 404 if there is no item with given key in the cache', function(done) {
                var component = {get: sinon.spy(function() {return Q(function() {return;}).call()})}
                DiContainer.setComponent('cache', component);
                cb({params: {0: 'key'}}, res).then(function() {
                    expect(res.send).to.have.been.calledOnce.and.calledWith(404);
                    done();
                });
            });
            _it('responds with 200 status if record with given key is in the cache', function(done) {
                var component = {get: sinon.spy(function() {return Q(function() {return 'data';}).call()})}
                DiContainer.setComponent('cache', component);
                cb({params: {0: 'key'}}, res).then(function() {
                    expect(res.end).to.have.been.calledOnce.and.calledWith('data');
                    done();
                });
            });
        });
    });
});