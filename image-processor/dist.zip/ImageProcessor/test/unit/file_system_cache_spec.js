/**
 * Created by dmytro@clevertech.biz on 29.01.14.
 */
var FileSystemCache = require('../../models/file_system_cache'),
    FileSystemStorage = require('../../models/file_system_storage'),
    DiContainer = require('../../models/di_container'),
    storage_path = 'test/filestorage',
    Q = require('q');

/**
 * Fake data source
 * @constructor
 */
var KeyStorageClass = function(colection) {
    this.setCollection(colection);
};
KeyStorageClass.prototype.setCollection = function() {}
KeyStorageClass.prototype.find = function() {return Q(function() {return []}).call()}

describe('FileSystemCache', function() {
    var cache,
        counter = 0;

    beforeEach(function() {
        cache = new FileSystemCache('test'+counter, KeyStorageClass);
        counter++;
    });

    _it("sets a root storage dir for cache", function(done) {
        sinon.spy(FileSystemStorage.prototype, 'setStorageRootDir');
        cache.setRootDir(storage_path).then(function() {
            expect(FileSystemStorage.prototype.setStorageRootDir).to.have.been.called.and.calledWith(storage_path);
            FileSystemStorage.prototype.setStorageRootDir.restore();
            done();
        });
    });

    describe("getUrls method", function() {
        var origin_data_id_one = 'key1',
            origin_data_id_two = 'key2',
            origin_data_keys = [origin_data_id_one, origin_data_id_two],
            spec_one = 'w100',
            spec_two = 'h200',
            specs = [spec_one, spec_two];

        _it("searches for keys documents in the key storage", function(done) {
            sinon.spy(KeyStorageClass.prototype, 'find');
            cache.getUrls(origin_data_keys, specs).then(function() {
                expect(KeyStorageClass.prototype.find).to.have.been.called.and.calledWith({_id: {$in: origin_data_keys}});

                KeyStorageClass.prototype.find.restore();
                done();
            });
        });

        _it("returns a map of results", function(done) {
            cache.getUrls(origin_data_keys, specs).then(function(urls) {
                expect(urls).to.have.been.instanceOf(Object);
                done();
            });
        });

        _it("returns a null for each spec if there is no key record for origin data", function(done) {
            cache.getUrls(origin_data_keys, specs).then(function(urls) {
                expect(urls[origin_data_id_one][spec_one]).to.have.been.null;
                expect(urls[origin_data_id_one][spec_two]).to.have.been.null;
                expect(urls[origin_data_id_two][spec_one]).to.have.been.null;
                expect(urls[origin_data_id_two][spec_two]).to.have.been.null;
                done();
            });
        });

        _it("returns a url for each spec if there is a cahced data for it", function(done) {
            var domain = 'http://cached.com',
                old_find = KeyStorageClass.prototype.find,
                found_record_one = {
                    _id: origin_data_id_one,
                    specs: {}
                },
                found_record_two = {
                    _id: origin_data_id_two,
                    specs: {}
                },
                cache_key_one = '1/1',
                cache_key_two = '2/2';
            found_record_one.specs[spec_one] = cache_key_one;
            found_record_two.specs[spec_two] = cache_key_two;
            KeyStorageClass.prototype.find = sinon.spy(function() {return Q(function() {return [found_record_one, found_record_two]}).call()});

            DiContainer.setParam('domain',domain);
            cache.getUrls(origin_data_keys, specs).then(function(urls) {
                expect(urls[origin_data_id_one][spec_one]).to.have.been.equal(cache.getUrl(cache_key_one));
                expect(urls[origin_data_id_one][spec_two]).to.have.been.null;
                expect(urls[origin_data_id_two][spec_one]).to.have.been.null;
                expect(urls[origin_data_id_two][spec_two]).to.have.been.equal(cache.getUrl(cache_key_two));

                KeyStorageClass.prototype.find = old_find;
                done();
            });
        });
    });

    _it("generates an cached url using domain and saved items key", function() {
        var domain = 'http://cached.com';

        DiContainer.setParam('domain',domain);

        expect(cache.getUrl('key')).to.have.been.equal(domain+'/cache/key');
        expect(cache.getUrl('/1/2/3')).to.have.been.equal(domain+'/cache/1/2/3');
    });
});