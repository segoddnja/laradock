/**
 * Created by dmytro@clevertech.biz on 2/9/14.
 */
var BaseCache = require('../../models/base_cache'),
    Q = require('q');

/**
 * Fake data source
 * @constructor
 */
var KeyStorageClass = function(colection) {
    this.setCollection(colection);
};
KeyStorageClass.prototype.setCollection = function() {}
KeyStorageClass.prototype.findOne = function() {return Q(function() {return}).call()}
KeyStorageClass.prototype.find = function() {return Q(function() {return []}).call()}
KeyStorageClass.prototype.insert = function() {return Q(function() {return}).call()}
KeyStorageClass.prototype.update = function() {return Q(function() {return}).call()}
KeyStorageClass.prototype.remove = function() {return Q(function() {return}).call()}

describe('BaseCache', function() {
    var cache,
        counter = 0;

    beforeEach(function() {
        cache = new BaseCache('test'+counter, KeyStorageClass);
        counter++;
    });

    _it('accepts unique cache id as param for constructor', function() {
        var cache = new BaseCache('nice_cache', KeyStorageClass);
        expect(cache.getId()).to.have.been.equal('nice_cache');
    });

    _it('throws an exception if id is empty', function() {
        var error_thrown = false;
        try {
            new FileSystemCache();
        } catch (e) {
            error_thrown = true;
        }
        expect(error_thrown).to.have.been.true;
    });

    _it('accepts a data source class and creates its instance for key storage purpose', function() {
        sinon.spy(KeyStorageClass.prototype, 'setCollection');
        var cache_id = 'mongo_based_cache';
        var cache = new BaseCache(cache_id, KeyStorageClass);
        expect(KeyStorageClass.prototype.setCollection).to.have.been.called.and.calledWith('BaseCache_keys_'+cache_id);
        KeyStorageClass.prototype.setCollection.restore();
    });

    describe('Save method', function() {

        var data = 'data',
            origin_data_id = 'origin_data_id',
            spec = 'w100_h200',
            new_filesystem_key = '1/2/3',
            storage = {};

        beforeEach(function() {
            storage.save = sinon.spy(function() {return Q(function() {return new_filesystem_key}).call()});
            cache.getStorage = function() {return storage}
        });

        _it("saves data in the data storage", function(done) {
            cache.save(data, origin_data_id, spec).then(function() {
                expect(storage.save).to.have.been.called.and.calledWith(data);
                done();
            });
        });

        _it("searches for keys document in the key storage", function(done) {
            sinon.spy(KeyStorageClass.prototype, 'findOne');
            cache.save(data, origin_data_id, spec).then(function() {
                expect(KeyStorageClass.prototype.findOne).to.have.been.called.and.calledWith({_id: origin_data_id});
                KeyStorageClass.prototype.findOne.restore();
                done();
            });
        });

        _it("creates new key record in the storage if there is no record for origin data", function(done) {
            sinon.spy(KeyStorageClass.prototype, 'insert');
            cache.save(data, origin_data_id, spec).then(function() {
                var record_for_insert = {_id: origin_data_id, specs: {}};
                record_for_insert['specs'][spec] = new_filesystem_key;
                expect(KeyStorageClass.prototype.insert).to.have.been.called.and.calledWith(record_for_insert);
                KeyStorageClass.prototype.insert.restore();
                done();
            });
        });

        _it("updates key record in the storage if there is no cached spec", function(done) {
            var old_find_one = KeyStorageClass.prototype.findOne,
                found_record = {
                    _id: origin_data_id
                };
            KeyStorageClass.prototype.findOne = sinon.spy(function() {return Q(function() {return found_record}).call()});
            sinon.spy(KeyStorageClass.prototype, 'update');

            cache.save(data, origin_data_id, spec).then(function() {
                var record_for_update = {_id: origin_data_id, specs: {}};
                record_for_update['specs'][spec] = new_filesystem_key;
                expect(KeyStorageClass.prototype.update).to.have.been.called.and.calledWith(origin_data_id, record_for_update);

                KeyStorageClass.prototype.update.restore();
                KeyStorageClass.prototype.findOne = old_find_one;
                done();
            });
        });

        _it("does not save data in the data storage if it is already cached", function(done) {
            var old_find_one = KeyStorageClass.prototype.findOne,
                found_record = {
                    _id: origin_data_id,
                    specs: {}
                };
            found_record['specs'][spec] = new_filesystem_key;
            KeyStorageClass.prototype.findOne = sinon.spy(function() {return Q(function() {return found_record}).call()});
            sinon.spy(KeyStorageClass.prototype, 'insert');
            sinon.spy(KeyStorageClass.prototype, 'update');

            cache.save(data, origin_data_id, spec).then(function() {
                expect(storage.save).to.have.not.been.called;
                expect(KeyStorageClass.prototype.update).to.have.not.been.called;
                expect(KeyStorageClass.prototype.insert).to.have.not.been.called;

                KeyStorageClass.prototype.update.restore();
                KeyStorageClass.prototype.insert.restore();
                KeyStorageClass.prototype.findOne = old_find_one;
                done();
            });
        });

    });

    describe('Delete method', function() {

        var origin_data_id = 'key',
            storage = {};

        beforeEach(function() {
            storage.delete = sinon.spy(function() {return Q(function() {return new_filesystem_key}).call()});
            cache.getStorage = function() {return storage}
        });

        _it("searches for keys document in the key storage", function(done) {
            sinon.spy(KeyStorageClass.prototype, 'findOne');
            cache.delete(origin_data_id).then(function() {
                expect(KeyStorageClass.prototype.findOne).to.have.been.called.and.calledWith({_id: origin_data_id});
                KeyStorageClass.prototype.findOne.restore();
                done();
            });
        });

        _it("does nothing if there is no cached data for given origin_data_id", function(done) {
            sinon.spy(KeyStorageClass.prototype, 'remove');
            cache.delete(origin_data_id).then(function() {
                expect(storage.delete).to.have.been.not.called;
                expect(KeyStorageClass.prototype.remove).to.have.been.not.called;

                KeyStorageClass.prototype.remove.restore();
                done();
            });
        });

        _it("removes key record from keys storage", function(done) {
            var old_find_one = KeyStorageClass.prototype.findOne,
                found_record = {
                    _id: origin_data_id
                };
            KeyStorageClass.prototype.findOne = sinon.spy(function() {return Q(function() {return found_record}).call()});
            sinon.spy(KeyStorageClass.prototype, 'remove');

            cache.delete(origin_data_id).then(function() {
                expect(KeyStorageClass.prototype.remove).to.have.been.called.and.calledWith(origin_data_id);

                KeyStorageClass.prototype.remove.restore();
                KeyStorageClass.prototype.findOne = old_find_one;
                done();
            });
        });

        _it("removes all cached specs from the data storage", function(done) {
            var old_find_one = KeyStorageClass.prototype.findOne,
                found_record = {
                    _id: origin_data_id,
                    specs: {
                        w100: '1',
                        w200: '2'
                    }
                };
            KeyStorageClass.prototype.findOne = sinon.spy(function() {return Q(function() {return found_record}).call()});

            cache.delete(origin_data_id).then(function() {
                expect(storage.delete).to.have.been.calledTwice.and.calledWith('1').and.calledWith('2');

                KeyStorageClass.prototype.findOne = old_find_one;
                done();
            });
        });
    });


    _it("gets data from the cache", function(done) {
        var data = 'data',
            storage = {
                get: sinon.spy(function() {return Q(function() {return data}).call()})
            },
            key = 'key';
        cache.getStorage = function() {return storage}

        cache.get(key).then(function(cached_data) {
            expect(cached_data).to.have.been.equal(data);
            expect(storage.get).to.have.been.called.and.calledWith(key);
            done();
        });
    });
});