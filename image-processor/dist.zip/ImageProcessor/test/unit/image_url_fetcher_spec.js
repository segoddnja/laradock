/**
 * Created by dmytro@clevertech.biz on 31.01.14.
 */
var ImageUrlFetcher = require('../../models/image_url_fetcher'),
    Image = require('../../models/image'),
    DiContainer = require('../../models/di_container'),
    Q = require('q');

return describe('ImageUrlFetcher', function(){
    var generate_route = '/gen',
        fetcher,
        origin_data_id_one = 'key1',
        image_one = new Image({_id: 1, binary_data: {key: origin_data_id_one}}),
        origin_data_id_two = 'key2',
        image_two = new Image({_id: 2, binary_data: {key: origin_data_id_two}}),
        images = [image_one, image_two],
        spec_one = 'w100',
        spec_two = 'h200',
        specs = [spec_one, spec_two];

    beforeEach(function() {
        fetcher = new ImageUrlFetcher();
    });

    describe('if cache component configured', function() {

        var component;

        beforeEach(function() {
            component = {
                getUrls: sinon.spy(function() {return Q(function() {return {};}).call()})
            };
            DiContainer.setComponent('cache', component);
        });

        describe('init method', function() {
            _it('calls getUrls method of cache component', function(done) {
                fetcher.init(images, specs).then(function() {
                    expect(component.getUrls).to.have.been.called.and.calledWith([origin_data_id_one, origin_data_id_two], specs);
                    done();
                });
            });

            _it('can deal with wrong spec formats', function(done) {
                fetcher.init(images, [spec_one, 'ab']).then(function() {
                    expect(component.getUrls).to.have.been.called.and.calledWith([origin_data_id_one, origin_data_id_two], [spec_one]);
                    done();
                });
            });
        });

        describe('getUrl method', function() {
            _it('returns link to generate endpoint if the instance is not initialized', function() {
                var domain = 'http://domain.com';
                DiContainer.setParam('domain', domain);
                expect(fetcher.getUrl(image_one, spec_one)).to.have.been.equal(domain+generate_route+'?key='+image_one.getId()+'&spec='+spec_one);
            });

            _it('returns link to cached version if it exists', function(done) {
                var cached_link = 'link',
                    urls = {};
                urls[origin_data_id_one] = {};
                urls[origin_data_id_one][spec_one] = cached_link;
                component = {
                    getUrls: sinon.spy(function() {return Q(function() {return urls;}).call()})
                };
                DiContainer.setComponent('cache', component);

                fetcher.init(images, specs).then(function() {
                    expect(fetcher.getUrl(image_one, spec_one)).to.have.been.equal(cached_link);
                    done();
                });
            });
        });
    });

    _it('always returns links to generate endpoint if cache component is not configured', function(done) {
        DiContainer.setComponent('cache', null);
        var domain = 'http://domain.com';
        DiContainer.setParam('domain', domain);
        fetcher.init(images, specs).then(function() {
            expect(fetcher.getUrl(image_one, spec_one)).to.have.been.equal(domain+generate_route+'?key='+image_one.getId()+'&spec='+spec_one);
            done();
        });
    });

    it('getUrl method return empty response for spec with wrong format', function() {
        expect(fetcher.getUrl(image_one, 'ab')).to.have.been.undefined;
    });
});