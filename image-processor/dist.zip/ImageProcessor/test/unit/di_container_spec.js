/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
var DiContainer = require('../../models/di_container'),
    Q = require('q');

describe('DiContainer', function() {
    _it('accept an application component as common source', function() {
        var global_name = 'component',
            component = {a: 'test', b: function(){}};
        DiContainer.setComponent(global_name, component);

        expect(DiContainer.getComponent(global_name)).to.be.equal(component);
    });
    _it('accept an application param as common source', function() {
        var global_name = 'param',
            value = 'test';
        DiContainer.setParam(global_name, value);

        expect(DiContainer.getParam(global_name)).to.be.equal(value);
    });
    describe('Configure', function() {
        _it('accepts params object', function(done) {
            DiContainer.configure({params: {
                param1: 'test1',
                param2: 'test2'
            }}).then(function() {
                expect(DiContainer.getParam('param1')).to.be.equal('test1');
                expect(DiContainer.getParam('param2')).to.be.equal('test2');
                done();
            });
        });

        _it('accepts components object', function(done) {
            sinon.spy(DiContainer, 'setComponent');

            DiContainer.configure({components: {
                component1: {inc: 'fs'},
                component2: {inc: 'fs'}
            }}).then(function() {
                expect(DiContainer.setComponent).to.have.been.calledTwice.and.calledWith('component1', require('fs')).and.calledWith('component2', require('fs'));

                DiContainer.setComponent.restore();
                done();
            });
        });

        _it('if component config has initializer method calls it and sets result as component', function(done) {
            sinon.spy(DiContainer, 'setComponent');
            var component1 = {test: function(){}},
                component1_initializer = sinon.spy(function() {return component1});

            DiContainer.configure({components: {
                component1: {
                    inc: 'fs',
                    initializer: component1_initializer
                }
            }}).then(function() {
                expect(component1_initializer).to.have.been.called;
                expect(DiContainer.setComponent).to.have.been.calledOnce.and.calledWith('component1', component1);

                DiContainer.setComponent.restore();
                done();
            });
        });
    })
});