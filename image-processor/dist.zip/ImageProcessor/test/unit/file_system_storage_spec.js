/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
var FileSystemStorage = require('../../models/file_system_storage'),
    storage_path = 'test/filestorage',
    Q = require('q'),
    fs = require('fs'),
    crypto = require('crypto');

var deleteFolderRecursive = function(path) {
    if( fs.existsSync(path) ) {
        fs.readdirSync(path).forEach(function(file,index){
            var curPath = path + "/" + file;
            if(fs.statSync(curPath).isDirectory()) { // recurse
                deleteFolderRecursive(curPath);
            } else { // delete file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
};


describe('FileSystemStorage', function(){
    return describe('It', function() {
        var file_system_storage;
        beforeEach(function(done) {
            file_system_storage = new FileSystemStorage();
            file_system_storage.setStorageRootDir(storage_path).then(function() {
                done();
            })
        });

        afterEach(function(){
            deleteFolderRecursive(storage_path);
        });

        _it("creates a root storage dir if it does not exist", function(done){
            fs.exists(storage_path, function(exists) {
                expect(exists).to.be.true;
                done();
            });
        });

        _it("creates a container with unique name for data", function(done){
            file_system_storage.save('12345').then(function() {
                fs.exists(storage_path + '/1', function(exists) {
                    expect(exists).to.be.true;
                    done();
                });
            });
        });

        _it("returns unique key for any saved data piece", function(done){
            var data = '12345',
                data_piece_name = crypto.createHash('md5').update(data).digest('hex');
            file_system_storage.save(data).then(function(key) {
                expect(key).to.be.equal('1/'+data_piece_name);
                done();
            });
        });

        _it("creates a file for any saved data piece", function(done){
            file_system_storage.save('12345').then(function(key) {
                fs.stat(storage_path+'/'+key, function(err, stat) {
                   expect(stat.isFile()).to.be.true;
                   done();
                });
            });
        });

        _it("should split files into directories with maximum 10000 files per dir", function(done) {
            /**
             * This way works pretty slow
             * for(var i=1; i<=10000; i++)
             *   fs.writeFileSync(storage_path + '/1/' + i, '');
             *
             * So we stub fs.readdir to simulate directory with 100000 files in it.
             */
            var old_read_dir = fs.readdir;
            fs.readdir = function(directory, callback) {
                if(directory == storage_path) {
                    callback(null, ['1', '10', '2', '3', '4', '5', '6', '7', '8', '9']);
                } else if(directory == storage_path + '/11') {
                    callback(null, []);
                } else {
                    var response = [];
                    for(var i=1; i<=10000; i++)
                        response.push(i);

                    callback(null, response);
                }
            };

            fs.mkdirSync(storage_path + '/1/');

            file_system_storage.save('12345').then(function(key) {
                expect(key.substr(0, 3)).to.be.equal('11/');
                fs.readdir = old_read_dir;
                done();
            });
        });

        _it("should return data by using it's key", function(done) {
            Q.ninvoke(fs, "readFile", 'test/fixtures/domino.png').then(function(data) {
                data = data.toString();
                file_system_storage.save(data).then(function(key) {
                    file_system_storage.get(key).then(function(response_data) {
                        expect(response_data.toString().length).to.be.equal(data.length);
                        done();
                    });
                });
            });
        });

        _it("should return null if there is no data", function(done) {
            file_system_storage.get('test_key').then(function(response_data) {
                expect(response_data).to.be.equal(null);
                done();
            });
        });

        _it("should delete data by using it's key", function(done) {
            Q.ninvoke(fs, "readFile", 'test/fixtures/domino.png').then(function(data) {
                data = data.toString();

                file_system_storage.save(data).then(function(key) {
                    file_system_storage.delete(key).then(function() {
                        file_system_storage.get(key).then(function(response_data) {
                            expect(response_data).to.be.equal(null);
                            done();
                        });
                    });
                });
            });
        });
    });
});