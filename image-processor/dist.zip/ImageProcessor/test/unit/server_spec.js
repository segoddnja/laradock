/**
 * Created by dmytro@clevertech.biz on 16.12.13.
 */
var server, restify, npmPackage, config;
server = require('../../lib/server');
restify = require('restify');
npmPackage = require('../../package.json');
config = require('../../lib/config');

sinon.stub(config, 'init', function() {return Q(function(){})});

var Q = require('q');
describe('server', function(){
    return describe('#create()', function(){
        var sut;
        beforeEach(function(){
            sinon.spy(restify, 'createServer');
            return sut = server.create();
        });
        afterEach(function(){
            return restify.createServer.restore();
        });
        _it('creates a restify server', function(done){
            sut.then(function() {
                expect(restify.createServer.callCount).to.be.equal(1);
                done();
            });
        });
        _it('sets server.name from package.json', function(done){
            sut.then(function(server) {
                expect(server).to.have.property('name', npmPackage.name);
                done();
            });
        });
        return _it('sets server.versions from package.json', function(done){
            sut.then(function(server) {
                expect(server).to.have.property('versions', npmPackage.version);
                done();
            });
        });
    });
});