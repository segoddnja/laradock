var config = {
    params: {
        /**
         * default maximal thumbnail size, you can override it in local config
         */
        max_thumbnail_size: 250,
        /**
         * default domain, need to be overridden in local config
         */
        domain: 'http://localhost:3000',
        need_auth_routes: {
            '/images': '*'
        },
        meta_data_source_options: {
            host: 'localhost',
            port: 27017,
            db: 'image_processor'
        }
    },
    components: {
        /**
         * Meta data source for image. Default is mongo storage.
         */
        image_meta_data_source: {
            inc: '../models/mongo_data_source',
            initializer: function(component) {
                return new component('image');
            }
        },
        /**
         * Binary data source for images. Default is the file system.
         */
        image_binary_data_source: {
            inc: '../models/file_system_storage',
            initializer: function(component) {
                var instance = new component();
                return instance.setStorageRootDir('runtime/storage').then(function() {
                    return instance;
                });
            }
        },
        /**
         * Cache for processed image specs. Default is a cache based on the file system.
         */
        cache: {
            inc: '../models/file_system_cache',
            initializer: function(component) {
                var instance = new component('specs', require(__dirname+'/models/mongo_data_source'));
                return instance.setRootDir('runtime/cache').then(function() {
                    return instance;
                });
            }
        }
    }
};

module.exports = config;