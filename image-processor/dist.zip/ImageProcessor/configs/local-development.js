module.exports = {
  components: {
    image_binary_data_source: {
      inc: '../models/file_system_storage',
      initializer: function(component) {
        var instance = new component();
        return instance.setStorageRootDir('/var/lib/image-storage/storage').then(function() {
          return instance;
        });
      }
    },
    cache: {
      inc: '../models/file_system_cache',
      initializer: function(component) {
        var instance = new component('specs', require(__dirname+'/models/mongo_data_source'));
        return instance.setRootDir('/var/lib/image-storage/cache').then(function() {
          return instance;
        });
      }
    }
  }
};