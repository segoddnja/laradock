module.exports = {
  params: {
    PORT: 8080,
    domain: 'http://img-prod.domino.com',
    service_credentials: {
      username: 'domino',
      password: 'ht4rT2we4Vz'
    },
    meta_data_source_options: {
      connectionString: 'mongodb://rs01,rs02/image_processor?replicaSet=Domino'
    }
  },
  components: {
    cache: false,
    image_binary_data_source: {
      inc: '../models/file_system_storage',
      initializer: function(component) {
        var instance = new component();
        return instance.setStorageRootDir('/var/www/vhosts/image-storage/storage').then(function() {
          return instance;
        });
      }
    }
  }
};
