/**
 * Created by dmytro@clevertech.biz on 31.01.14.
 */
var DiContainer = require('../models/di_container'),
    ImageSpec = require('../models/image_spec'),
    Q = require('q');

var generate_route = '/gen'

var ImageUrlFetcher = function() {
    this._getUrls = function() {return {}}
}

/**
 *
 * @param Image[] images
 * @param array specs
 * @returns {*}
 */
ImageUrlFetcher.prototype.init = function(images, specs) {
    var self = this;

    return Q(function() {
        var cache = DiContainer.getComponent('cache');
        if(!cache)
            return;

        var binary_data_keys = [];
        for(var i in images)
            binary_data_keys.push(images[i].getBinaryDataKey());

        var formated_specs = [];
        for(var j in specs) {
            try {
                formated_specs.push(_correct_format_of_spec(specs[j]));
            } catch(e) {}
        }

        return cache.getUrls(binary_data_keys, formated_specs).then(function(urls) {
            self._getUrls = function() {return urls}
        });
    }).call();
}

ImageUrlFetcher.prototype.getUrl = function(image, spec) {
    try {
        spec = _correct_format_of_spec(spec);
        var urls = this._getUrls(),
            binary_data_key = image.getBinaryDataKey();
        return urls[binary_data_key] && urls[binary_data_key][spec] ?
            urls[binary_data_key][spec] : (DiContainer.getParam('domain'))+generate_route+'?key='+image.getId()+'&spec='+spec;
    } catch(e) {}
}

var _correct_format_of_spec = function(spec) {
    if(spec instanceof ImageSpec)
        return spec.getKey();

    return new ImageSpec(spec).getKey();
}

module.exports = ImageUrlFetcher;