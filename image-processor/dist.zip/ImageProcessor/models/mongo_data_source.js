/**
 * Created by dmytro@clevertech.biz on 18.12.13.
 */
'use strict';
var
    DiContainer = require('../models/di_container'),
    MongoClient = require('mongodb').MongoClient,
    ObjectID = require('mongodb').ObjectID,
    extend = require('util')._extend,
    _db;

(function()
{
    var
        options = DiContainer.getParam("meta_data_source_options"),
        connectionString = options.connectionString;

    if (!connectionString) {
      var
        auth_part = options.username ? options.username + ":" + options.password + "@" : "",
        host = "mongodb://" + auth_part + options.host;

      connectionString = [host, options.port].join(":") + "/" + options.db;
    }


    MongoClient.connect(connectionString).then(function(db) {_db = db;});
})();

var MongoDataSource = function(collection) {
    this._collection_name = collection;
};

function _getCollection()
{
    if(this._collection)
        return this._collection;

    this._collection = _db.collection(this._collection_name);
    return this._collection;
}

function ensureID(id) {
    try {
        return new ObjectID(id);
    } catch($e) {
        return id;
    }
}

/**
 * It's just a wrapper around Collection.insert. Resolves promise with new record id.
 * @param {Object} record
 * @returns {Promise}
 */
MongoDataSource.prototype.insert = function(record) {
    return _getCollection.apply(this).insert(record)
        .then(function(data) {
            return data.ops instanceof Array && data.ops[0] ? data.ops[0]._id : null;
        });
};

/**
 * This method is wrapper around Collection.update method.
 * It replaces old document data with a given new one.
 * @param {ObjectId|str} id
 * @param {Object} data
 * @returns {Promise}
 */
MongoDataSource.prototype.update = function(id, data) {
    var _data = extend({}, data);
    delete(_data._id);
    return _getCollection.apply(this).update({_id: ensureID(id)}, {$set: _data});
};

/**
 * It's just a wrapper around Collection.remove.
 * @param {ObjectId|str} id
 * @returns {Promise|promise}
 */
MongoDataSource.prototype.remove = function(id) {
    return _getCollection.apply(this).remove({_id: ensureID(id)}, {w:1});
};

/**
 * It's just a wrapper around Collection.findOne.
 * @param query
 * @returns {Promise}
 */
MongoDataSource.prototype.findOne = function(query) {
    return _getCollection.apply(this).findOne(query);
};

/**
 * It's just a wrapper around Collection.find.
 * @param {Object} query
 * @param {int} offset
 * @param {int} limit
 * @param {Object} sort
 * @returns {Promise}
 */
MongoDataSource.prototype.find = function(query, offset, limit, sort) {
    var cursor = _getCollection.apply(this).find(_preprocessQuery(query));
    if(offset > 0)
        cursor.skip(parseInt(offset));

    if(limit > 0)
        cursor.limit(parseInt(limit));

    if (sort instanceof Object)
        cursor.sort(sort);

    return cursor.toArray();
};

var _preprocessQuery = function(query) {
    if(query._id instanceof Object && !(query._id instanceof ObjectID)) {
        for(var i in query._id) {
            if(query._id[i] instanceof Array) {
                for(var j in query._id[i])
                    query._id[i][j] = ensureID(query._id[i][j]);
            } else {
                query._id[i] = ensureID(query._id[i]);
            }
        }
    } else if(query._id) {
        query._id = ensureID(query._id);
    }

    return query;
};

module.exports = MongoDataSource;