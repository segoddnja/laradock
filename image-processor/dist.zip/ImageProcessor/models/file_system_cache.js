/**
 * Created by dmytro@clevertech.biz on 29.01.14.
 */
var FileSystemStorage = require('../models/file_system_storage'),
    BaseCache = require('../models/base_cache'),
    DiContainer = require('../models/di_container'),
    util = require('util'),
    Q = require('q');

function FileSystemCache(id, KeyStorageClass) {
    FileSystemCache.super_.call(this, id, KeyStorageClass);

    var storage = new FileSystemStorage();
    this.getStorage = function() {return storage}
}

util.inherits(FileSystemCache, BaseCache);

/**
 * Sets base directory for the cache.
 * @param string path
 * @returns {promise|Q.promise}
 */
FileSystemCache.prototype.setRootDir = function(path) {
    return this.getStorage().setStorageRootDir(path);
};

/**
 * Accepts array of origin binary data keys and specs and returns a set of urls for each binary data key.
 * If there is no cached spec for combination of binary data and spec than returned url is null.
 * @param origin_data_keys
 * @param specs
 * @returns {*}
 */
FileSystemCache.prototype.getUrls = function(origin_data_keys, specs) {
    var self = this;
    origin_data_keys = origin_data_keys instanceof Array ? origin_data_keys : [origin_data_keys];

    return this.getKeyStorage().find({_id: {$in: origin_data_keys}}).then(function(key_records) {
        var result = {};

        for(var r in key_records) {
            var key_record = key_records[r],
                urls = {};

            for(var s in specs)
                if(key_record.specs[specs[s]])
                    urls[specs[s]] = self.getUrl(key_record.specs[specs[s]]);
                else
                    urls[specs[s]] = null;

            result[key_record._id] = urls;
        }

        for(var k in origin_data_keys) {
            if(!result[origin_data_keys[k]]) {
                result[origin_data_keys[k]] = {};
                for(var s in specs)
                    result[origin_data_keys[k]][specs[s]] = null;
            }
        }

        return result;
    });
};

/**
 * @param key
 */
FileSystemCache.prototype.getUrl = function(key) {
    return DiContainer.getParam('domain') + '/cache/' + key.replace(/^\/|\/$/g, '');
};

module.exports = FileSystemCache;