/**
 * Created by dmytro@clevertech.biz on 2/9/14.
 */
var ids = {};

/**
 * Virtual class for caches. Descendants should implement getStorage method which should return instance of Storage.
 * @param string id
 * @param string KeyStorageClass
 * @constructor
 */
function BaseCache(id, KeyStorageClass) {
    if(!id)
        throw new Error('Id can\'t be empty!');

    this.getId = function(){return id;}
    ids[id] = true;

    var key_storage = new KeyStorageClass(this.constructor.name+'_keys_'+id);
    this.getKeyStorage = function() {return key_storage}
}

/**
 * Saves the data in the cache.
 * @param data
 * @param origin_data_key
 * @param spec
 */
BaseCache.prototype.save = function(data, origin_data_key, spec) {
    var self = this;
    return this.getKeyStorage().findOne({_id: origin_data_key}).then(function(keys_collection) {
        if(keys_collection && keys_collection['specs'] && keys_collection['specs'][spec])
            return;

        return self.getStorage().save(data).then(function(key) {
            if(!keys_collection) {
                var object_for_insert = {_id: origin_data_key, specs: {}};
                object_for_insert['specs'][spec] = key;
                return self.getKeyStorage().insert(object_for_insert);
            } else {
                keys_collection['specs'] = keys_collection['specs'] || {};
                keys_collection['specs'][spec] = key;
                return self.getKeyStorage().update(origin_data_key, keys_collection);
            }
        });
    });
};

/**
 * Removes all cached specs from data storage and key record from keys storage.
 * @param origin_data_key
 */
BaseCache.prototype.delete = function(origin_data_key) {
    var self = this;
    return this.getKeyStorage().findOne({_id: origin_data_key}).then(function(keys_collection) {
        if(keys_collection) {
            self.getKeyStorage().remove(origin_data_key);
            if(keys_collection.specs)
                for(var i in keys_collection.specs)
                    self.getStorage().delete(keys_collection.specs[i]);
        }
        return;
    });
};

/**
 * @param key
 * @returns binary data
 */
BaseCache.prototype.get = function(key) {
    return this.getStorage().get(key);
};

/**
 * @param key
 * @returns binary data
 */
BaseCache.prototype.getKeys = function(key) {
  return this.getKeyStorage().findOne({_id: key}).then(function(key_record) {
    return key_record ? key_record['specs'] : null;
  });
};

module.exports = BaseCache;