/**
 * Created by dmytro@clevertech.biz on 1/11/16.
 */
'use strict';
var
  AWS = require('aws-sdk'),
  fs = require('fs'),
  Q = require('q'),
  crypto = require('crypto'),
  MAX_FILES_PER_DIR = 10000;

AWS.config.update({accessKeyId: 'AKIAIFUE5HGHBPACNF6Q', secretAccessKey: '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'});

var s3 = new AWS.S3();

var S3Storage = function () {
};

/**
 * @param {string} name
 */
S3Storage.prototype.setBucketName = function (name) {
  this._bucket_name = name;
};

/**
 * @param {Buffer} data
 * @param {string} key
 * @returns {promise|Q.promise}
 */
S3Storage.prototype.save = function (data, key) {

  var
    d = Q.defer(),
    self = this;

  Q(function () {
    if (key)
      return key;

    return _getCurrentDirectoryName(self._bucket_name)
      .then(function (path) {
        return getUniqueFileName(path, data);
      });
  }).call()
    .then(function (path) {
      var
        params = {Bucket: self._bucket_name, Key: path, Body: data},
        options = {partSize: 10 * 1024 * 1024, queueSize: 1};
      s3.upload(params, options, function(err, data) {
        if (err) {
          d.reject(err);
          return;
        }

        d.resolve(path);
      });
    });

  return d.promise;
};

S3Storage.prototype.get = function (key) {
  var
    d = Q.defer(),
    params = {
      Bucket: this._bucket_name,
      Key: key
    };

  s3.getObject(params, function(err, data) {
    if (err) {
      d.resolve(null);
      return;
    }

    d.resolve(data.Body);
  });

  return d.promise;
};

function _getCurrentDirectoryName(bucket_name) {
  var
    d = Q.defer(),
    params = {
      Bucket: bucket_name,
      Delimiter: '/'
    };
  s3.listObjects(params, function(err, data) {
    if (err) {
      d.reject(err);
      return;
    }

    d.resolve(data.CommonPrefixes.pop()['Prefix'].slice(0,-1));
  });

  return d.promise;
}

var getUniqueFileName = function (path, data) {
  return path + '/' + crypto.createHash('md5').update(data).digest('hex');
};

S3Storage.prototype.delete = function (key) {
  var
    d = Q.defer(),
    params = {
      Bucket: this._bucket_name,
      Key: key
    };

  s3.deleteObject(params, function(err, data) {
    if (err) {
      d.reject(err);
      return;
    }

    d.resolve();
  });

  return d.promise;
};

module.exports = S3Storage;