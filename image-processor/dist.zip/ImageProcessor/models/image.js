/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
'use strict';
var DiContainer = require('../models/di_container'),
  ImageProcessor = require('../models/image_processor'),
  crypto = require('crypto'),
  extend = require('util')._extend,
  Q = require('q'),
  http = require('http'),
  url = require('url'),

  ObjectID = require('mongodb').ObjectID;

require('buffer');

var newrelic;
try {
  newrelic = require('newrelic');
} catch (e) {
  /** do nothing */
}

var _setInternalState = function (meta_data) {
  meta_data = meta_data || {};
  if (!meta_data._id && this.getMetaData)
    meta_data._id = this.getId();

  this.getMetaData = function () {
    return extend({}, meta_data)
  }
};

var Image = function (meta_data) {
  _setInternalState.call(this, meta_data);
};

var get_meta_data_source = function () {
  return DiContainer.getComponent('image_meta_data_source');
};

var get_binary_data_storage = function () {
  return DiContainer.getComponent('image_binary_data_source');
};

/**
 * @returns string
 */
Image.prototype.getId = function () {
  return this.getMetaData()._id;
};

/**
 * @returns null|Buffer
 */
Image.prototype.getBinaryData = function () {
  var self = this,
    meta_data = this.getMetaData(),
    has_binary_data = meta_data.binary_data && meta_data.binary_data.key,
    has_link_to_image = meta_data.characteristics && meta_data.characteristics.url,
    d = Q.defer();

  if (!has_binary_data && !has_link_to_image)
    d.resolve(null);

  if (has_binary_data) {
    get_binary_data_storage().get(meta_data.binary_data.key).then(function (data) {
      d.resolve(data);
    });
  } else if (has_link_to_image) {
    var parsed_link = url.parse(meta_data.characteristics.url);
    var request = http.request({
      host: parsed_link.host,
      path: parsed_link.path,
      port: 80
    });

    request.on('response', function (res) {
      var body = '';
      res.setEncoding('binary');
      res.on('data', function (data) {
        body += data;
      });
      res.on('end', function () {
        if (res.statusCode == '200') {
          body = new Buffer(body, 'binary');
          self.setBinaryData(body).then(function () {
            d.resolve(body);
          });
        } else {
          d.resolve(null);
        }
      });
    });
    request.on('error', function () {
      d.resolve(null);
    });
    request.end();
  }

  return d.promise;
};

/**
 * @returns string
 */
Image.prototype.getBinaryDataKey = function () {
  var meta_data = this.getMetaData();
  return meta_data.binary_data ? meta_data.binary_data.key : null;
};

/**
 * @param {ImageSpec} spec
 */
Image.prototype.getImageDataProcessedToSpec = function (spec) {
  var self = this;
  return this.getBinaryData().then(function (data) {
    if (data) {
      var meta_data = self.getMetaData();
      return new ImageProcessor().processToSpec(data, spec, meta_data.characteristics.type).then(function (processed_data) {
        var cache_component = DiContainer.getComponent('cache');
        if (cache_component)
          cache_component.save(processed_data, meta_data.binary_data.key, spec.getKey());

        return processed_data;
      });
    } else {
      throw new Error('Image does not have binary data!');
    }
  });
};

/**
 * @param binary_data
 * @returns {promise|Q.promise}
 */
Image.prototype.setBinaryData = function (binary_data) {
  var MimeDetector = require('../lib/mime_detector'),
    meta_data = this.getMetaData(),
    old_binary_data_key = meta_data.binary_data && meta_data.binary_data.key ? meta_data.binary_data.key : null,
    image_processor = new ImageProcessor(),
    binary_data_digest = crypto.createHash('md5').update(binary_data).digest('hex'),
    self = this;

  return MimeDetector.detect(binary_data).then(function (result) {
    if (result.split('/')[0] != 'image' && result != 'binary') {
      throw new TypeError('Wrong data type');
    } else {
      meta_data.characteristics = meta_data.characteristics || {};
      meta_data.characteristics.type = result;

      return get_meta_data_source().findOne({
        'binary_data.bites': binary_data.length,
        'binary_data.digest': binary_data_digest
      })
    }
  }).then(function (existed_data) {
    return Q(function () {
      return get_binary_data_storage().save(binary_data, existed_data ? existed_data.binary_data.key : null);
    }).call()
  }).then(function (key) {
      return image_processor.getImageDimensions(binary_data).then(function (dimensions) {
        meta_data.characteristics.dimensions = dimensions;
        return key;
      });
    })
    .then(function (key) {
      meta_data.binary_data = {
        key: key,
        bites: binary_data.length,
        digest: binary_data_digest
      };
      return get_meta_data_source().update(meta_data._id, meta_data).then(function () {
        _setInternalState.call(self, meta_data);
        if (old_binary_data_key)
          return _collectBinaryGarbage(old_binary_data_key);
      });
    });
};

/**
 * @param {string} url
 */
Image.prototype.setSourceUrl = function (url) {
  var meta_data = this.getMetaData(),
    self = this;
  meta_data.characteristics = meta_data.characteristics || {};
  meta_data.characteristics.url = url;
  return get_meta_data_source().update(meta_data._id, meta_data).then(function () {
    _setInternalState.call(self, meta_data);
  });
};

/**
 *
 * @param additional
 * @returns {Promise}
 */
Image.prototype.setAdditionalData = function (additional) {
  var meta_data = this.getMetaData(),
    self = this;
  meta_data.additional = additional;
  return get_meta_data_source().update(meta_data._id, meta_data).then(function () {
    _setInternalState.call(self, meta_data);
  });
};

/**
 *
 * @param {int} width
 * @param {int} height
 * @param {int} x
 * @param {int} y
 * @returns {Promise}
 */
Image.prototype.crop = function (width, height, x, y) {
  if (!width || !height || !x || !y)
    throw new Error('Image does not have binary data!');

  var self = this;
  return this.getBinaryData().then(function (data) {
    if (data) {
      return new ImageProcessor().crop(data, width, height, x, y).then(function (cropped_data) {
        return self.setBinaryData(cropped_data);
      });
    } else {
      throw new Error('Image does not have binary data!');
    }
  });
};

/**
 * @returns {*}
 */
Image.prototype.delete = function () {
  var meta_data = this.getMetaData();
  return get_meta_data_source().remove(meta_data._id).then(function () {
    return Q(function () {
      if (meta_data.binary_data && meta_data.binary_data.key) {
        return _collectBinaryGarbage(meta_data.binary_data.key)
      }
    }).call();
  });
};

var _collectBinaryGarbage = function (binary_data_key) {
  return get_meta_data_source().find({'binary_data.key': binary_data_key}).then(function (records) {
    if (records.length > 0)
      return;

    get_binary_data_storage().delete(binary_data_key);
    var cache = DiContainer.getComponent('cache');
    if (cache)
      cache.delete(binary_data_key);
  });
};

/**
 * @param {String} profile
 * @param {Buffer} data
 * @param {Object|JSON} additional
 * @returns {promise|Q.promise}
 */
Image.create = function (profile, data, additional) {
  if (!profile)
    throw new Error('profile is required!');

  if (additional && additional.constructor.name == 'String')
    additional = JSON.parse(additional);

  var data_for_insert = {
    characteristics: {
      group: profile
    },
    additional: additional
  };

  return get_meta_data_source().insert(data_for_insert).then(function (id) {
    data_for_insert._id = id;
    var image = new Image(data_for_insert);
    return Q(function () {
      if (data)
        return image.setBinaryData(data);
    })
      .call()
      .then(function () {
        return image;
      });
  });
};

/**
 * @param {String} profile
 * @param {String} file Path to the image file
 * @param {Object|JSON} additional
 * @returns {*}
 */
Image.createFromFile = function (profile, file, additional) {
  if (!profile)
    throw new Error('profile is required!');

  if (!file)
    throw new Error('file is required!');

  return Q.ninvoke(require('fs'), "readFile", file)
    .catch(function () {
      throw new TypeError('Wrong file path!');
    })
    .then(function (file_data) {
      return Image.create(profile, file_data, additional);
    });
};

/**
 * @param {String} profile
 * @param {String} url Link to the image file
 * @param {Object|JSON} additional
 * @returns {*}
 */
Image.createFromUrl = function (profile, url, additional) {
  if (!profile)
    throw new Error('profile is required!');

  if (!url)
    throw new Error('url is required!');

  return get_meta_data_source().findOne({'characteristics.url': url}).then(function (image_data) {
    if (image_data)
      return new Image(image_data);

    if (additional && additional.constructor.name == 'String')
      additional = JSON.parse(additional);

    var data_for_insert = {
      characteristics: {
        group: profile,
        url: url
      },
      additional: additional
    };

    //@todo temporary trick to make migration procedure work
    if (additional && additional._id) {
      data_for_insert['_id'] = new ObjectID(additional._id);
      delete data_for_insert.additional._id;
    }

    return get_meta_data_source().insert(data_for_insert).then(function (id) {
      data_for_insert._id = id;
      return new Image(data_for_insert);
    });
  });
};

/**
 * @param {Object} query
 * @param {int} offset
 * @param {int} limit
 * @returns {Function|promise|Q.promise}
 */
Image.get = function (query, offset, limit) {
  var d = Q.defer(),
    result = [];

  var sort = {_id: -1}; // enforced sorting of images is natural (creation) order, descending.
  get_meta_data_source().find(query, offset, limit, sort).then(function (records) {
    for (var i in records)
      result.push(new Image(records[i]));

    d.resolve(result);
  });

  return d.promise;
};

if (newrelic) {
  newrelic.createTracer('Image.get', Image.get);
  newrelic.createTracer('Image.createFromUrl', Image.createFromUrl);
  newrelic.createTracer('Image.createFromFile', Image.createFromFile);
  newrelic.createTracer('Image.create', Image.create);
  newrelic.createTracer('Image.prototype.crop', Image.prototype.crop);
  newrelic.createTracer('Image.prototype.setAdditionalData', Image.prototype.setAdditionalData);
  newrelic.createTracer('Image.prototype.setBinaryData', Image.prototype.setBinaryData);
  newrelic.createTracer('Image.prototype.getImageDataProcessedToSpec', Image.prototype.getImageDataProcessedToSpec);
  newrelic.createTracer('Image.prototype.getImageDataProcessedToSpec', Image.prototype.getImageDataProcessedToSpec);
  newrelic.createTracer('Image.prototype.getBinaryData', Image.prototype.getBinaryData);
}

module.exports = Image;