/**
 * Created by dmytro@clevertech.biz on 23.01.14.
 */
var Q = require('q'),
  gm = require('gm'),
  DiContainer = require('../models/di_container'),
  ImageSpec = require('../models/image_spec'),
  path = require('path'),
  profile_path = path.resolve('sRGB_IEC61966-2-1_black_scaled.icc'),
  circle_thumb_mask_path = path.resolve('circle_thumbnail_mask.png');

require('buffer');

var ImageProcessor = function () {
};

/**
 * @returns Buffer
 */
ImageProcessor.prototype.processToSpec = function (data, spec) {

  var
    d = Q.defer(),
    processor = gm(data);

  processor.format({bufferStream: true}, function (err, format) {
    if (err)
      return d.reject(err);

    processor
    //.coalesce()//make sure that size transformations won't break animated gif
      .profile(profile_path)//apply color profile to the image
      .strip();//remove all meta data

    Q(function () {
      if (spec.hasCropParams() !== true)
        return processor;

      processor
        .crop(spec.getCropWidth(), spec.getCropHeight(), spec.getCropX(), spec.getCropY())//and crop it
        .repage(spec.getCropWidth(), spec.getCropHeight(), 0, 0);//repage image to fix possible issue with animated gif

      return processor;
    })
      .call()
      .then(function (processor) {

        if (spec.getWidth() || spec.getHeight()) {
          processor
            .resize(spec.getWidth() > 0 ? spec.getWidth() : null, spec.getHeight() > 0 ? spec.getHeight() : null, '>');//resize image
        }

        processor
          .interlace(format.toLowerCase() != 'gif' ? 'line' : null)//make progressive jpeg
          .quality(spec.getQuality());//and set result image quality

        if (spec.isCircleThumbnailMode())
          processor
            .resize(219, 219)//fit image into the mask image size
            .background('white')//set white background for extent
            .gravity('Center')//center image
            .extent(219, 219);//and extent image

        processor.toBuffer(function (err, buffer) {
          if (err)
            return d.reject(err);

          if (!spec.isCircleThumbnailMode())
            return d.resolve(buffer);

          /** we need to finish circle thumbnail preparations before apply the mask */
          gm(buffer)
            .composite(circle_thumb_mask_path)
            .toBuffer(function (err, result) {
              d.resolve(result);
            });
        });
      });
  });

  return d.promise;
};

/**
 * @returns Buffer
 */
ImageProcessor.prototype.crop = function (data, width, height, x, y) {
  return this.processToSpec(data, new ImageSpec({
    width: width,
    height: height,
    crop_width: width,
    crop_height: height,
    crop_x: x,
    crop_y: y
  }));
};

ImageProcessor.prototype.getImageDimensions = function (data) {
  var d = Q.defer();

  gm(data).size(function (err, size) {
    if (err)
      d.reject(err);
    else
      d.resolve(size);
  });

  return d.promise;
};

module.exports = ImageProcessor;
