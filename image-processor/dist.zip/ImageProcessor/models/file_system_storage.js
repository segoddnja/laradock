/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
'use strict';
var fs = require('fs'),
  Q = require('q'),
  crypto = require('crypto'),
  MAX_FILES_PER_DIR = 10000;

var get_file_path_by_key = function (key) {
  return this.getRootDirPath() + '/' + key;
};

var FileSystemStorage = function () {};

/**
 * @param {string} path
 * @returns {promise|Q.promise}
 */
FileSystemStorage.prototype.setStorageRootDir = function (path) {
  var d = Q.defer(),
    self = this;

  fs.exists(path, function (exists) {
    if (exists === true) {
      d.resolve();
      self.getRootDirPath = function () {
        return path
      };
    } else {
      fs.mkdir(path, function (err) {
        if (err) {
          d.reject(err);
        } else {
          self.getRootDirPath = function () {
            return path
          };
          d.resolve();
        }
      });
    }
  });

  return d.promise;
};

/**
 * @param {Buffer} data
 * @param {string} key
 * @returns {promise|Q.promise}
 */
FileSystemStorage.prototype.save = function (data, key) {
  var
    self = this,
    d = Q.defer(),
    storage_root_dir_path = this.getRootDirPath();

  Q(function() {
    if(key)
      return get_file_path_by_key.call(self, key);

    return getCurrentContainerPath.apply(self)
      .then(function(path) {
        return getUniqueFileName(path, data);
      });
  }).call()
    .then(function(path) {
      fs.writeFile(path, data, function (err) {
        if (err) {
          d.reject(err);
        } else {
          d.resolve(path.replace(storage_root_dir_path + '/', ''));
        }
      });
    });

  return d.promise;
};

FileSystemStorage.prototype.get = function (key) {
  var d = Q.defer();

  Q.ninvoke(fs, "readFile", get_file_path_by_key.call(this, key))
    .then(function (data) {
      d.resolve(data);
    })
    .catch(function () {
      d.resolve(null);
    });

  return d.promise;
};

var getCurrentContainerPath = function () {
  var d = Q.defer(),
    current_container_path,
    storage_root_dir_path = this.getRootDirPath();

  Q.ninvoke(fs, "readdir", storage_root_dir_path).then(function (files) {
    if (files.length === 0) {
      current_container_path = storage_root_dir_path + '/1';
      Q.ninvoke(fs, "mkdir", current_container_path).then(function () {
        d.resolve(current_container_path);
      });
    } else {
      files.sort(function (a, b) {
        if (a * 1 < b * 1)
          return -1;
        else if (a * 1 > b * 1)
          return 1;
        return 0;
      });
      var last_dir = parseInt(files.pop());
      current_container_path = storage_root_dir_path + '/' + last_dir;
      Q.ninvoke(fs, "readdir", current_container_path).then(function (files) {
        if (files.length >= MAX_FILES_PER_DIR) {
          current_container_path = storage_root_dir_path + '/' + (last_dir + 1);
          Q.ninvoke(fs, "mkdir", current_container_path).then(function () {
            d.resolve(current_container_path);
          });
        } else {
          d.resolve(current_container_path);
        }
      });
    }
  });

  return d.promise;
};

var getUniqueFileName = function (path, data) {
  return path + '/' + crypto.createHash('md5').update(data).digest('hex');
};

FileSystemStorage.prototype.delete = function (key) {
  return Q.ninvoke(fs, "unlink", get_file_path_by_key.call(this, key));
};

module.exports = FileSystemStorage;