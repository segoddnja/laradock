/**
 * Created by dmytro@clevertech.biz on 23.01.14.
 */

var AVAILABLE_SPEC_PARAMS = {
    w: 'width',
    h: 'height',
    cw: 'crop_width',
    ch: 'crop_height',
    cx: 'crop_x',
    cy: 'crop_y',
    q: 'quality'
};

var _parse_spec_string = function(spec_str) {
    if(spec_str == 'o')
        return {width: 1000, height: 1000};

    var parts = spec_str.split('_'),
        result = {};

    for(var i in parts) {
        var part = parts[i];
        if(part == 'circlethumb')
          result.circlethumb = true;
        for(var j in AVAILABLE_SPEC_PARAMS) {
            if(_starts_with(part, j)) {
                result[AVAILABLE_SPEC_PARAMS[j]] = parseInt(part.replace(j, ''));
            }
        }
    }

    return result;
};

var _starts_with = function(haystack, needle) {
    return haystack.substr(0, needle.length) === needle;
};

var ImageSpec = function(spec) {
    if(spec instanceof Object)
        this._config = spec;
    else
        this._config = _parse_spec_string(spec);

    if(!this._config.width && !this._config.height)
        throw new Error('Wrong spec format!');
};

/**
 * @returns int
 */
ImageSpec.prototype.getWidth = function() {
    return this._config.width || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getHeight = function() {
    return this._config.height || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getCropWidth = function() {
    return this._config.crop_width || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getCropHeight = function() {
    return this._config.crop_height || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getCropX = function() {
    return this._config.crop_x || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getCropY = function() {
    return this._config.crop_y || 0;
};

/**
 * @returns int
 */
ImageSpec.prototype.getQuality = function() {
	return this._config.quality || 90;
};

/**
 * @returns {boolean}
 */
ImageSpec.prototype.hasCropParams = function() {
    return this.getCropWidth() > 0 || this.getCropHeight() > 0;
};

/**
 * @returns {boolean}
 */
ImageSpec.prototype.isCircleThumbnailMode = function() {
  return this._config.circlethumb;
};

/**
 * @returns str
 */
ImageSpec.prototype.getKey = function() {
    var result_parts = [];

    for(var i in AVAILABLE_SPEC_PARAMS)
        if(this._config[AVAILABLE_SPEC_PARAMS[i]])
            result_parts.push(i+this._config[AVAILABLE_SPEC_PARAMS[i]]);

    if(this.isCircleThumbnailMode())
      result_parts.push('circlethumb');

    return result_parts.join('_');
};

module.exports = ImageSpec;
