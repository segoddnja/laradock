/**
 * Created by dmytro@clevertech.biz on 26.12.13.
 */
'use strict';
var Q = require('q');

var _components = {},
    _params = {};

var DiContainer = {
    setComponent: function(name, component) {
        _components[name] = component;
    },
    getComponent: function(name) {
        return _components[name];
    },
    setParam: function(name, value) {
        _params[name] = value;
    },
    getParam: function(name) {
        return _params[name];
    },
    configure: function(options) {
        options = options || {};
        var self = this,
            d = Q.defer();

        if(options.params) {
            for(var i in options.params)
                self.setParam(i, options.params[i]);
        }

        if(options.components) {
            var ensure_component_initialization_complete = (function(components_count, deferred){
                var processed_components_count = 0;
                return function() {
                    processed_components_count++;
                    if(components_count === processed_components_count)
                        deferred.resolve();
                }
            })(Object.keys(options.components).length, d);

            for(var i in options.components) {
                var component_config = options.components[i];

                if(!component_config || !component_config.inc) {
                    ensure_component_initialization_complete();
                    continue;
                }

                var component_class = require(component_config.inc);

                if(component_config.initializer) {
                    (function(name, config){
                        Q(config.initializer)
                            .call(this, component_class)
                            .then(function(component) {
                                DiContainer.setComponent(name, component);
                                ensure_component_initialization_complete();
                            }, function(err){
                                console.log(i, err);
                                ensure_component_initialization_complete();
                            });
                    })(i, component_config);
                } else {
                    self.setComponent(i, component_class);
                    ensure_component_initialization_complete();
                }
            }
        } else {
            d.resolve();
        }

        return d.promise;
    }
}

module.exports = DiContainer;