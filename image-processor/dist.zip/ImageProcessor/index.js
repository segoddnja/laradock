#!/usr/bin/env nodemon -e js,ls
'use strict';

var cluster = require('cluster');

process.chdir(__dirname);

if (cluster.isMaster) {
    for (var i = 0; i < require('os').cpus().length; i++) {
        cluster.fork();
    }

    cluster.on('disconnect', function() {
        console.error('disconnect!');
        cluster.fork();
    });

} else {
    require('./lib/server').create().then(function(server) {
        var DiContainer = require('./models/di_container');
        var port = DiContainer.getParam('PORT') || 3000;
        server.listen(port, function() {
            console.log('%s#%s listening at %s', server.name, server.versions, server.url);
        });
    });
}